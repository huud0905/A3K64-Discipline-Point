/* ============================================================
   A3K64 — Sơ đồ chỗ ngồi — Vanilla JS (port 1:1 từ React/TSX)
   Không cần React, không cần Babel, không cần bước build.
   ============================================================ */

/* ---------- Storage keys ---------- */
const SEAT_STORAGE_KEY     = 'a3k64-seating-map-v1';
const SEAT_DB_KEY          = 'a3k64-seating-sheet-local-db-v1';
const SEAT_CURRENT_KEY     = 'a3k64-seating-sheet-current-id-v1';
const SEAT_PUBLISH_PREFIX  = 'a3k64-seating-publish-lite-v1:';
const SEAT_LOCKED_KEY      = 'a3k64-seating-locked-students-v1';

/* ---------- Dữ liệu mặc định — lưới trống (chờ tải từ backend) ---------- */
const SEAT_DEFAULT = {
  left:  Array.from({ length: 7 }, () => ['', '', '', '']),
  right: Array.from({ length: 7 }, () => ['', '', '', '']),
};

/* ---------- Cấu hình phòng (cửa sổ / cửa / nhãn hàng trước) ----------
 * Khác lớp khác phòng thì vị trí cửa sổ, cửa, hoặc tên nhãn (BÀN GV/BẢNG/
 * CỬA RA VÀO) có thể khác nhau — nên để dữ liệu-hoá thay vì hardcode.
 * Lưu kèm trong layout.room của mỗi sơ đồ (đã có cột room_json ở backend). */
const SEAT_DEFAULT_ROOM = {
  windows: {
    left:  [{ top: 14, height: 90 }, { top: 61, height: 90 }],
    right: [{ top: 9,  height: 90 }, { top: 37, height: 90 }],
  },
  door: { side: 'right', top: 74, height: 108 },
  front: [
    { key: 'teacher',    icon: 'desk',       label: 'BÀN GV' },
    { key: 'board-label',icon: 'blackboard', label: 'BẢNG' },
    { key: 'door',       icon: 'doorOpen',   label: 'CỬA RA VÀO' },
  ],
};
function cloneRoom(r) { return JSON.parse(JSON.stringify(r)); }
function clampNum(v, min, max, fallback) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : fallback;
}
function normalizeWindowList(list, fallback) {
  const src = Array.isArray(list) && list.length ? list : fallback;
  return src.slice(0, 4).map((w, i) => ({
    top:    clampNum(w && w.top,    2, 96, fallback[i]?.top || (10 + i * 25)),
    height: clampNum(w && w.height, 30, 260, fallback[i]?.height || 90),
  }));
}
function normalizeRoom(raw) {
  const r = raw && typeof raw === 'object' ? raw : {};
  const windows = r.windows && typeof r.windows === 'object' ? r.windows : {};
  const door = r.door && typeof r.door === 'object' ? r.door : {};
  const front = Array.isArray(r.front) && r.front.length ? r.front : null;
  return {
    windows: {
      left:  normalizeWindowList(windows.left,  SEAT_DEFAULT_ROOM.windows.left),
      right: normalizeWindowList(windows.right, SEAT_DEFAULT_ROOM.windows.right),
    },
    door: {
      side:   door.side === 'left' ? 'left' : 'right',
      top:    clampNum(door.top,    2, 96,  SEAT_DEFAULT_ROOM.door.top),
      height: clampNum(door.height, 30, 260, SEAT_DEFAULT_ROOM.door.height),
    },
    front: (front || SEAT_DEFAULT_ROOM.front).slice(0, 3).map((f, i) => ({
      key:   String(f?.key || SEAT_DEFAULT_ROOM.front[i]?.key || `slot${i}`),
      icon:  String(f?.icon || SEAT_DEFAULT_ROOM.front[i]?.icon || 'desk'),
      label: String(f?.label || SEAT_DEFAULT_ROOM.front[i]?.label || ''),
    })),
  };
}

/* ---------- Bảng mapping: tên ngắn (seat_name) → họ tên đầy đủ ---------- *
 * Hardcode 1:1 — không cần cột seat_name trong ACCOUNTS, không cần so khớp  *
 * đuôi tên. Mọi chỗ hiển thị tên đều qua seatFullName(name).                */
const SEAT_FULL_NAME = {
  'A Đạt':      'Phan Anh Đạt',
  'Bảo':        'Lê Hoàng Đức Bảo',
  'C Trường':   'Nguyễn Lê Công Trường',
  'D Hiếu':     'Dương Trung Hiếu',
  'Duy':        'Nguyễn Văn Khánh Duy',
  'Đ Minh':     'Phạm Đăng Minh',
  'Đan':        'Nguyễn Bùi Linh Đan',
  'Đức':        'Nguyễn Minh Đức',
  'Đức An':     'Nguyễn Bá Đức An',
  'Đức Anh':    'Lương Hoàng Đức Anh',
  'Đức Nam':    'Nguyễn Đức Nam',
  'H Giang':    'Phan Thị Hương Giang',
  'H Nhi':      'Nguyễn Lê Hải Nhi',
  'Hà Linh':    'Nguyễn Hà Linh',
  'Hà Tâm':    'Hà Minh Tâm',
  'Hằng':       'Nguyễn Thị Hằng',
  'Hiền Linh':  'Lê Hiền Linh',
  'Hoàng Linh': 'Nguyễn Hoàng Linh',
  'Hữu':        'Đinh Mạnh Hữu',
  'Huy Đạt':   'Nguyễn Huy Thành Đạt',
  'K Linh':     'Nguyễn Khánh Linh',
  'K Ngân':    'Nguyễn Thị Kim Ngân',
  'Khánh':      'Nguyễn Ngọc Nam Khánh',
  'Lê Mạnh':   'Nguyễn Lê Đức Mạnh',
  'Lộc':        'Mai Thanh Lộc',
  'Mạnh':       'Thái Đức Mạnh',
  'N Hiếu':    'Nguyễn Ngọc Hiếu',
  'N Minh':    'Hoàng Nguyễn Nhật Minh',
  'Na':         'Vi Kim Na',
  'Nhân':       'Nguyễn Trọng Nhân',
  'Như':        'Lê Hoàng Gia Như',
  'Q Nhi':     'Nguyễn Quỳnh Nhi',
  'Quân':       'Nguyễn Bảo Quân',
  'Sang':       'Phạm Tiến Sang',
  'Sáng':       'Phạm Minh Sáng',
  'T Tâm':     'Phạm Thanh Tâm',
  'Tài':        'Lê Văn Tấn Tài',
  'Thành':      'Trần Văn Thành',
  'Thành Đạt': 'Nguyễn Thành Đạt',
  'Thắm':       'Nguyễn Thị Hồng Thắm',
  'Thắng':      'Nguyễn Chiến Thắng',
  'Thiện':      'Nguyễn Minh Thiện',
  'Thơ':        'Lê Thị Anh Thơ',
  'Thục Anh':  'Lê Thục Anh',
  'Thuỷ':       'Thái Thị Thuỳ',
  'Tiến':       'Đặng Lê Tiến',
  'Tinh':       'Nguyễn Văn Quang Tinh',
  'Trang':      'Nguyễn Thị Thu Trang',
  'Trí':        'Nguyễn Minh Trí',
  'Trung':      'Nguyễn Hữu Trung',
  'Tuấn':       'Nguyễn Văn Tuấn',
  'V Trường':  'Võ Văn Trường',
  'Việt An':   'Ngô Việt An',
  'Y Nhi':     'Nguyễn Thị Yến Nhi',
};

/** Trả họ tên đầy đủ từ tên ngắn. Fallback về chính tên ngắn nếu không tìm thấy. */
function seatFullName(shortName) {
  const s = String(shortName || '').trim();
  return SEAT_FULL_NAME[s] || s;
}

/* Danh sách học sinh duy nhất, sort theo tiếng Việt — lấy từ danh sách lớp
 * (SEAT_FULL_NAME) chứ KHÔNG lấy từ SEAT_DEFAULT (lưới trống mặc định, chờ
 * tải dữ liệu thật từ backend). Trước đây lấy nhầm từ SEAT_DEFAULT nên danh
 * sách này luôn rỗng — kéo học sinh ra khỏi ghế để "bỏ xếp chỗ" bị mất tên
 * luôn vì sidebar không còn nơi nào để hiện lại tên đó. */
const SEAT_STUDENTS = Object.keys(SEAT_FULL_NAME).sort((a, b) => a.localeCompare(b, 'vi'));

/* ---------- Pure helpers ---------- */
function seatNorm(v) {
  return String(v || '').toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').trim();
}
function cloneState(s) {
  return { left: s.left.map(r => r.slice()), right: s.right.map(r => r.slice()) };
}
function normalizeRows(rows) {
  const norm = (Array.isArray(rows) ? rows : []).map(row => {
    const next = Array.isArray(row) ? row.slice(0, 4).map(x => String(x || '').trim()) : [];
    while (next.length < 4) next.push('');
    return next;
  });
  while (norm.length < 7) norm.push(['', '', '', '']);
  return norm.slice(0, 7);
}
function loadSeatState() {
  // Stale-while-revalidate: hiện ngay dữ liệu đã cache từ lần trước (DB local),
  // boot() sẽ fetch GAS ngầm và cập nhật nếu có thay đổi.
  // Chỉ dùng lưới trống khi chưa từng có sơ đồ nào được lưu.
  try {
    const savedId = localStorage.getItem(SEAT_CURRENT_KEY);
    const items = readDb();
    const cached = savedId
      ? items.find(i => i.id === savedId) || items.find(i => i.active) || items[0]
      : items.find(i => i.active) || items[0];
    if (cached?.layout?.seats) {
      const seats = cached.layout.seats;
      if (seats.left && seats.right) {
        return { left: normalizeRows(seats.left), right: normalizeRows(seats.right) };
      }
    }
  } catch (e) { /* ignore */ }
  return cloneState(SEAT_DEFAULT);
}
function saveSeatState(s) {
  localStorage.setItem(SEAT_STORAGE_KEY, JSON.stringify(s));
}
function findSeat(state, name) {
  const want = seatNorm(name);
  for (const side of ['left', 'right']) {
    for (let row = 0; row < state[side].length; row++) {
      for (let seat = 0; seat < state[side][row].length; seat++) {
        if (seatNorm(state[side][row][seat]) === want) return { side, row, seat };
      }
    }
  }
  return null;
}
function seatAt(state, pos) { return state[pos.side][pos.row]?.[pos.seat] || ''; }
function withSeatSet(state, pos, value) {
  const next = cloneState(state);
  next[pos.side][pos.row][pos.seat] = value;
  return next;
}
function withSeatMove(state, payload, target) {
  let next = cloneState(state);
  const targetName = seatAt(next, target);
  if (payload.type === 'seat') {
    if (payload.pos.side === target.side && payload.pos.row === target.row && payload.pos.seat === target.seat) return next;
    next = withSeatSet(next, payload.pos, targetName);
    next = withSeatSet(next, target, payload.name);
    return next;
  }
  // type === 'student'
  const current = findSeat(next, payload.name);
  if (current) next = withSeatSet(next, current, targetName);
  next = withSeatSet(next, target, payload.name);
  return next;
}
function seatAllAssigned(state) {
  return SEAT_STUDENTS.every(name => findSeat(state, name));
}

/* ---------- Multi-sheet local DB ---------- */
function readDb() {
  try {
    const db = JSON.parse(localStorage.getItem(SEAT_DB_KEY) || '{}');
    return Array.isArray(db.items) ? db.items : [];
  } catch { return []; }
}
function writeDb(items) { localStorage.setItem(SEAT_DB_KEY, JSON.stringify({ items })); }
/** Ghi layout (seats+room) đầy đủ của 1 sơ đồ vào DB nhiều-sơ-đồ (SEAT_DB_KEY).
 *
 * Trong chế độ gas (dataSource==='gas'), SEAT_DB_KEY trước giờ chỉ được ghi
 * bởi ensureDb() (seed mặc định lúc chưa có sơ đồ nào) và bởi preload.js
 * (chỉ có metadata từ listSeatingCharts — KHÔNG có layout.seats). Nghĩa là
 * layout thật chưa từng được lưu vào DB nhiều-sơ-đồ này — mỗi lần
 * preload.js chạy lại (login/reload), nó merge dựa trên layout cũ trong
 * DB, nhưng DB chưa bao giờ có layout để mà giữ lại → sơ đồ luôn phải chờ
 * gasGetChart() xong mới có gì để hiện.
 *
 * Gọi hàm này mỗi khi vừa fetch được layout thật từ gasGetChart() (boot(),
 * applySheet(), checkAccessNow()) để lần preload/reload sau, DB đã có sẵn
 * layout mà preload.js có thể giữ lại khi merge. */
function persistLayoutToDb(id, seats, room, metaHint) {
  if (!id || !seats) return;
  const items = readDb();
  let item = items.find(i => i.id === id);
  const now = new Date().toISOString();
  if (!item) {
    item = Object.assign({ id, title: metaHint?.title || '', active: true, createdAt: now, updatedAt: now }, metaHint || {});
    items.push(item);
  }
  item.layout = { seats, room: room || item.layout?.room || cloneRoom(SEAT_DEFAULT_ROOM), exportedAt: now };
  item.updatedAt = now;
  writeDb(items);
}
function ensureDb(seats) {
  let items = readDb();
  if (items.length) return items;
  const now = new Date().toISOString();
  const item = { id: `seat_${Date.now()}`, title: 'Sơ đồ 1', active: true, createdAt: now, updatedAt: now, layout: { seats, room: cloneRoom(SEAT_DEFAULT_ROOM), exportedAt: now } };
  items = [item];
  writeDb(items);
  localStorage.setItem(SEAT_CURRENT_KEY, item.id);
  return items;
}
function currentSheetId(sheets) {
  return localStorage.getItem(SEAT_CURRENT_KEY) || sheets.find(i => i.active)?.id || sheets[0]?.id || '';
}
function saveSheet(sheets, id, title, seats, room) {
  const items = sheets.length ? sheets.slice() : ensureDb(seats);
  const now = new Date().toISOString();
  let item = id ? items.find(i => i.id === id) : undefined;
  const roomToSave = room || item?.layout?.room || cloneRoom(SEAT_DEFAULT_ROOM);
  if (item) {
    item.title = title; item.layout = { seats, room: roomToSave, exportedAt: now }; item.updatedAt = now;
  } else {
    item = { id: `seat_${Date.now()}`, title, active: true, createdAt: now, updatedAt: now, layout: { seats, room: roomToSave, exportedAt: now } };
    items.push(item);
  }
  items.forEach(i => i.active = i.id === item.id);
  writeDb(items);
  localStorage.setItem(SEAT_CURRENT_KEY, item.id);
  return { items, item };
}
/* ---------- Khoá chỗ ngồi từng học sinh ----------
 * Học sinh đã "ok chỗ" thì khoá lại — nút Random sẽ bỏ qua, kéo-thả cũng
 * chặn luôn (không tự dưng bị đẩy đi khi người khác chỉnh sửa). Lưu local
 * theo tên học sinh (không phụ thuộc sơ đồ nào), không cần đồng bộ backend. */
function loadLockedStudents() {
  try {
    const arr = JSON.parse(localStorage.getItem(SEAT_LOCKED_KEY) || '[]');
    return new Set(Array.isArray(arr) ? arr.filter(Boolean) : []);
  } catch { return new Set(); }
}
function saveLockedStudents(set) {
  try { localStorage.setItem(SEAT_LOCKED_KEY, JSON.stringify(Array.from(set))); } catch { /* ignore */ }
}
function publishKey(id) { return `${SEAT_PUBLISH_PREFIX}${id}`; }
function readPublish(id) {
  try { return JSON.parse(localStorage.getItem(publishKey(id)) || 'null') || { status: 'private' }; }
  catch { return { status: 'private' }; }
}
function writePublish(id, config) { localStorage.setItem(publishKey(id), JSON.stringify(config)); }

/* ============================================================
   GAS API — sơ đồ chỗ ngồi thật sự lưu lên Google Sheets tại đây.
   Trước đây file này CHỈ đọc/ghi localStorage nên "sửa" trông như
   thành công nhưng không hề lên Sheet — người khác mở lại/đồng bộ
   lại thì mất. dataSource='gas' khi có gasUrl và load lần đầu OK,
   ngược lại rơi về 'local' (localStorage) như hành vi cũ.
   ============================================================ */
let gasUrl     = null;
let dataSource = 'local'; // 'local' | 'gas'
let userRole   = null;    // role của người đang đăng nhập (từ desktop session)
let userGroup  = null;    // số tổ của người đang đăng nhập (từ desktop session)

// Chỉ GVCN và lớp trưởng được sửa sơ đồ / xem sơ đồ khi đang riêng tư.
// Khớp với quyền phía backend (A3SeatFinal_canEditRole_ trong api.gs) —
// đổi ở đây thì nhớ đổi cả bên đó.
const SEAT_EDIT_ROLES = ['gvcn', 'loptruong'];
function seatRoleNorm(v) {
  return String(v || '').trim().toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/đ/g, 'd').replace(/[^a-z0-9]+/g, '');
}
function canEditSeating() { return SEAT_EDIT_ROLES.includes(seatRoleNorm(userRole)); }

// Kiểm tra người dùng hiện tại có trong danh sách xem trước không.
// previewStudents là chuỗi tên phân cách bằng dấu phẩy (lưu ở backend).
// Backend lưu tên NGẮN (seat_name) nhưng userName trong session là tên ĐẦY ĐỦ
// → so khớp theo cả hai chiều:
//   (1) seatNorm(entry) === seatNorm(userName)           — entry là tên đầy đủ
//   (2) seatNorm(seatFullName(entry)) === seatNorm(userName) — entry là tên ngắn → tra mapping lấy full
//   (3) seatNorm(entry) khớp với seatNorm của tên ngắn nào có full-name = userName — ngược lại
function isInPreviewList(previewStudents) {
  if (!userName) return false;
  const wantNorm = seatNorm(userName);
  // Tập các norm của tên ngắn mà full-name khớp với userName (tra ngược SEAT_FULL_NAME)
  const shortNormsForUser = Object.entries(SEAT_FULL_NAME)
    .filter(([, full]) => seatNorm(full) === wantNorm)
    .map(([short]) => seatNorm(short));

  return String(previewStudents || '').split(',')
    .map(n => n.trim()).filter(Boolean)
    .some(n => {
      const nNorm = seatNorm(n);
      // (1) entry khớp trực tiếp với userName (tên đầy đủ)
      if (nNorm === wantNorm) return true;
      // (2) entry là tên ngắn → tra mapping lấy full rồi so
      if (seatNorm(seatFullName(n)) === wantNorm) return true;
      // (3) entry là tên ngắn khớp với bất kỳ short-name nào của user
      if (shortNormsForUser.includes(nNorm)) return true;
      return false;
    });
}

// Người dùng hiện tại có thể xem sơ đồ không (kể cả preview)?
// - Luôn true với GVCN/lớp trưởng.
// - status='published'/'public'   → tất cả xem được.
// - status='preview'/'restricted' → chỉ những ai trong previewStudents.
// - status='private'              → chỉ GVCN/lớp trưởng (đã bắt ở trên).
//
// Worker (Cloudflare) dùng: 'private' | 'restricted' | 'public'
// UI frontend dùng:         'private' | 'preview'    | 'published'
// Hai helper dưới đây dịch qua lại — mọi chỗ so sánh dùng CANONICAL_STATUS
// (giá trị UI) nhờ seatStatusFromApi(); mọi chỗ gửi lên backend dùng
// seatStatusToApi() để worker không fallback về 'private'.

/** UI-label → API-value (gửi lên worker) */
function seatStatusToApi(uiStatus) {
  if (uiStatus === 'published') return 'public';
  if (uiStatus === 'preview')   return 'restricted';
  return 'private'; // 'private' giữ nguyên
}

/** API-value → UI-label (nhận từ worker) */
function seatStatusFromApi(apiStatus) {
  if (apiStatus === 'public')      return 'published';
  if (apiStatus === 'restricted')  return 'preview';
  return 'private'; // 'private' hoặc giá trị lạ
}

function canViewSeating(status, previewStudents) {
  if (canEditSeating()) return true;
  if (status === 'published') return true;
  if (status === 'preview') return isInPreviewList(previewStudents);
  return false;
}

// Polling: chỉ áp dụng cho người KHÔNG phải gvcn/lop_truong — họ luôn xem/sửa
// được nên không cần tự mở/tự khoá. Với người xem thường: cứ 10 giây kiểm
// tra lại trạng thái công bố — nếu đang bị chặn mà giờ đã công bố thì tự mở
// ra; nếu đang xem bình thường mà bị chuyển về riêng tư (GVCN khoá lại) thì
// khoá ngay, không cần đợi người dùng thao tác hay tải lại trang.
const SEAT_ACCESS_POLL_SECONDS = 10;
let seatAccessCountdown = SEAT_ACCESS_POLL_SECONDS;
let seatAccessPollTimer = null;

async function fetchFromGas(params = {}) {
  if (!gasUrl) return null;
  try {
    const url = new URL(gasUrl);
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, v));
    url.searchParams.set('t', String(Date.now()));
    const res = await fetch(url.toString(), { method: 'GET', redirect: 'follow' });
    return await res.json();
  } catch { return null; }
}
async function postToGas(action, payload = {}) {
  if (!gasUrl) return null;
  try {
    const body = JSON.stringify({ action, ...payload });
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 25000);
    let res;
    try { res = await fetch(gasUrl, { method: 'POST', body, signal: controller.signal }); }
    finally { clearTimeout(timeoutId); }
    return await res.json();
  } catch { return null; }
}
function gasData(json) { return json?.data || json || {}; }

async function gasListCharts() {
  const data = gasData(await fetchFromGas({ action: 'listSeatingCharts', role: userRole || '' }));
  return Array.isArray(data.charts) ? data.charts : [];
}
// Trả cả cờ restricted + status: khi sơ đồ đang riêng tư và người xem không
// đủ quyền, backend từ chối trả layout thật (chặn ngay ở API, không chỉ ẩn
// UI) — chart sẽ là null nhưng restricted=true để boot()/applySheet() biết
// lý do và không hiểu lầm là lỗi mạng.
async function gasGetChart(id) {
  const json = await fetchFromGas({ action: 'getSeatingChart', id: id || '', role: userRole || '' });
  const data = gasData(json);
  const rawStatus = json?.status || data.status || '';
  return { chart: data.chart || null, restricted: !!(json?.restricted || data.restricted), status: seatStatusFromApi(rawStatus) };
}
async function gasSaveChart(id, title, seats, room) {
  const json = await postToGas('saveSeatingChart', {
    id: id || '', title, layout: { seats, room: room || cloneRoom(SEAT_DEFAULT_ROOM) }, makeActive: true,
    role: userRole || '', actor: { name: userName, role: userRole },
  });
  const data = gasData(json);
  return { chart: data.chart || null, error: json?.ok === false ? (json.error || '') : (data.error || '') };
}
async function gasGetAccess(chartId, chartTitle) {
  const data = gasData(await fetchFromGas({ action: 'getSeatingAccess', chartId: chartId || '', chartTitle: chartTitle || '', role: userRole || '' }));
  const acc = data.access || { status: 'private' };
  return { ...acc, status: seatStatusFromApi(acc.status || 'private') };
}
// Gộp getSeatingChart + getSeatingAccess thành 1 request duy nhất.
// Backend trả { chart, access, restricted?, status? } — giảm từ 2 GAS call
// (~6-8s) xuống còn 1 call (~3-4s). Fallback về 2 call riêng nếu backend
// chưa hỗ trợ action này (data.chart === undefined && data.access === undefined).
async function gasGetChartWithAccess(id, chartTitle) {
  const json = await fetchFromGas({ action: 'getSeatingChartWithAccess', id: id || '', chartTitle: chartTitle || '', role: userRole || '' });
  const data = gasData(json);
  // Nếu backend chưa hỗ trợ action mới → trả null để caller fallback
  if (data.chart === undefined && data.access === undefined && !data.restricted) return null;
  const rawAccess = data.access || { status: 'private' };
  const rawStatus = json?.status || data.status || '';
  return {
    chart: data.chart || null,
    access: { ...rawAccess, status: seatStatusFromApi(rawAccess.status || 'private') },
    restricted: !!(json?.restricted || data.restricted),
    status: seatStatusFromApi(rawStatus),
  };
}
async function gasSaveAccess(chartId, chartTitle, status, previewStudents) {
  const json = await postToGas('saveSeatingAccess', {
    chartId: chartId || '', chartTitle: chartTitle || '', status: seatStatusToApi(status),
    previewStudents: previewStudents || '',
    role: userRole || '', actor: { name: userName, role: userRole },
  });
  const data = gasData(json);
  const rawAcc = data.access || null;
  const normAcc = rawAcc ? { ...rawAcc, status: seatStatusFromApi(rawAcc.status || 'private') } : null;
  return { access: normAcc, error: json?.error || data.error || null };
}

/* ---------- App state ---------- */
let seatState      = loadSeatState();
let sheets         = ensureDb(seatState);       // fallback cục bộ, ghi đè bằng dữ liệu GAS trong boot() nếu có
let currentId      = currentSheetId(sheets);
let publishConfig  = readPublish(currentId);
let roomConfig     = normalizeRoom(sheets.find(i => i.id === currentId)?.layout?.room);
let query          = '';
let editMode       = false;
let selectOpen     = false;
let modal          = null;   // null | 'create' | 'publish' | 'manage' | 'sheets'
let modalOpening   = false;  // true trong lượt render() đầu tiên sau openModal() — kích hoạt fade-in
let dragPayload    = null;   // { type, name, pos? }
let dragFrontIndex = null;   // index đang kéo trong hàng BÀN GV/BẢNG/CỬA
let roomDrag        = null;  // di chuyển tự do cửa sổ/cửa bằng chuột
let roomResize       = null; // đổi kích thước cửa sổ/cửa bằng chuột
let sidebarCollapsed = false; // true khi người dùng ẩn sidebar
// Mobile: gộp toàn bộ .seat-tools (chọn sơ đồ, tìm kiếm, bật sửa, icon
// phụ, hành động chính) vào 1 drawer thu gọn sau nút "Công cụ" để board
// có nhiều chỗ hơn trên màn hẹp — xem @media(max-width:600px) seating.css
let mobileToolsOpen = false;
let lockedStudents  = loadLockedStudents(); // Set<string> — tên học sinh đã khoá chỗ

/* ---------- Tự động lưu ----------
 * Mọi thay đổi (kéo-thả, random, reset, đổi cửa/cửa sổ...) không cần bấm
 * "Lưu sơ đồ" nữa — tự lưu ngầm sau một nhịp ngắn (debounce) để gộp nhiều
 * thao tác liên tiếp lại thành 1 lần lưu, tránh spam request lên Sheet. */
const SEAT_AUTOSAVE_DELAY_MS = 900;
let isDirty       = false;  // có thay đổi chưa được lưu (kể cả đang trong lúc debounce)
let isSavingNow   = false;
let autosaveTimer = null;

/* User from desktop session */
const ACCENT_COLORS = { blue:'#2563eb', violet:'#7c3aed', pink:'#db2777', green:'#059669', amber:'#d97706', red:'#dc2626' };
function readAccent() {
  for (const k of ['login-accent','accent-color','accent','desktop-accent','a3k64-accent']) {
    const raw = (localStorage.getItem(k) || '').trim();
    if (!raw) continue;
    if (/^#([0-9a-f]{3}|[0-9a-f]{6})$/i.test(raw)) return raw;
    if (ACCENT_COLORS[raw.toLowerCase()]) return ACCENT_COLORS[raw.toLowerCase()];
  }
  return '#2563eb';
}
function readDesktopUser() {
  try { return JSON.parse(sessionStorage.getItem('a3k64-user') || 'null'); } catch { return null; }
}
const desktopUser = readDesktopUser();
const userName    = desktopUser?.displayName || null;
document.documentElement.style.setProperty('--desktop-accent', readAccent());


/* ---------- Thông báo (sidebar) ---------- */
/* showToast → A3Notify (notify.js). Giữ tên hàm để không đổi các call site */
/* Đánh dấu vừa có thay đổi, hẹn giờ tự lưu (debounce). Gọi sau mọi thao tác
 * sửa sơ đồ (kéo-thả ghế, random, reset, đổi cửa/cửa sổ/hàng đầu lớp...). */
function markDirty() {
  isDirty = true;
  updateSaveStatus();
  clearTimeout(autosaveTimer);
  autosaveTimer = setTimeout(runAutosave, SEAT_AUTOSAVE_DELAY_MS);
}
async function runAutosave() {
  if (!canEditSeating() || !isDirty) return;
  await handleSaveSheet(true); // silent — không hiện toast, chỉ đổi trạng thái nút Lưu
}
function saveStatusLabel() {
  if (isSavingNow) return 'Đang lưu...';
  if (isDirty)     return 'Chưa lưu xong...';
  return 'Đã lưu';
}
/* Cập nhật riêng nút Lưu (không render() lại toàn bộ) để không mất focus
 * ô tìm kiếm hay làm gián đoạn thao tác đang dở của người dùng. */
function updateSaveStatus() {
  const btn = document.getElementById('btn-save');
  if (btn) btn.innerHTML = `${seatIcon('save', 18)} ${saveStatusLabel()}`;
}

/* Cảnh báo khi đóng/tải lại trang mà vẫn còn thay đổi chưa lưu xong (ví dụ
 * vừa sửa xong, tự lưu chưa kịp chạy hết debounce hoặc mạng đang chậm).
 * Với các cửa sổ desktop tự chế (không phải tab trình duyệt thật) do shell
 * bên ngoài quản lý nút "X", hãy gọi window.a3k64SeatingConfirmClose()
 * trước khi đóng để hỏi người dùng có muốn chờ lưu xong hay đóng luôn. */
window.addEventListener('beforeunload', (e) => {
  if (isDirty) { e.preventDefault(); e.returnValue = ''; }
});
window.a3k64SeatingConfirmClose = function () {
  if (!isDirty) return true; // đã lưu xong — đóng thoải mái
  const wantClose = window.confirm(
    'Sơ đồ vừa sửa đang được tự lưu — chưa xong. Bấm OK để đóng luôn (có thể mất vài thay đổi mới nhất), Huỷ để ở lại chờ lưu xong.'
  );
  if (!wantClose) { handleSaveSheet(true); return false; } // ở lại, đẩy lưu ngay cho nhanh xong
  return true; // đồng ý đóng dù chưa chắc lưu kịp
};

function showToast(msg, type) {
  if (window.A3Notify) {
    window.A3Notify.show(msg, { type: type || 'info' });
  } else {
    console.info('[A3K64]', msg);
  }
}

/* ============================================================
   RENDER — one big re-render, patching only what changed
   ============================================================ */
function render() {
  const root = document.getElementById('seating-root');
  if (!root) return;

  const editable = canEditSeating();
  const status = publishConfig.status || 'private';
  const previewStudents = publishConfig.previewStudents || publishConfig.preview_students || '';

  // Không đủ quyền xem → màn hình chặn.
  if (!canViewSeating(status, previewStudents)) {
    if (modal) modal = null;
    root.innerHTML = renderSeatBlocked(status);
    return;
  }
  // Người xem thường (không sửa được) không có lý do gì để mở modal quản lý.
  if (!editable && modal) modal = null;

  const currentTitle = sheets.find(i => i.id === currentId)?.title || 'Sơ đồ 1';
  const q = seatNorm(query);
  const unassignedStudents = SEAT_STUDENTS.filter(name => !findSeat(seatState, name));
  const filteredStudents = unassignedStudents.filter(name => !q || seatNorm(name).includes(q));

  root.innerHTML = `
<div class="seat-app">
  <!-- ── Toolbar ── -->
  <div class="seat-toolbar${mobileToolsOpen ? ' mobile-tools-open' : ''}">
    <div class="seat-heading">
      <div>
        <h1>SƠ ĐỒ CHỖ NGỒI LỚP 12A3</h1>
        <p>${editable ? 'Bật sửa rồi kéo tên vào ghế, hoặc kéo đổi chỗ BÀN GV / BẢNG / CỬA RA VÀO' : 'Đang xem ở chế độ chỉ đọc.'}</p>
      </div>
      <!-- Chỉ hiện trên mobile (CSS) — gộp toàn bộ .seat-tools vào 1 drawer -->
      <button id="btn-mobile-tools-toggle" class="seat-mobile-tools-toggle" title="Công cụ & cài đặt" aria-expanded="${mobileToolsOpen}">
        ${seatIcon('settings', 18)}
        <span>Công cụ</span>
        ${seatIcon('chevronDown', 14)}
      </button>
    </div>
    <div class="seat-tools">
      <!-- (a) Cụm chọn sơ đồ & quản lý -->
      <div class="seat-group seat-group-left">
        <div class="seat-select${selectOpen ? ' open' : ''}" id="sheet-select">
          <button class="seat-select-trigger" id="btn-sheet-trigger">
            ${seatIcon('layoutGrid', 18)}
            <span>${escH(currentTitle)}</span>
            ${seatIcon('chevronDown', 18)}
          </button>
          <div class="seat-select-menu">
            ${sheets.map(item => `
              <button class="seat-select-option${item.id === currentId ? ' active' : ''}" data-sheet-id="${escH(item.id)}">${escH(item.title || 'Sơ đồ')}</button>
            `).join('')}
          </div>
        </div>
        ${editable ? `<button id="btn-manage-sheets" class="seat-icon-btn" title="Quản lý sơ đồ (đổi tên / sao chép / xoá)">${seatIcon('layers', 18)}</button>` : ''}
        ${editable ? `<button id="btn-manage" class="seat-icon-btn" title="Quản lý công bố">${seatIcon('settings', 18)}</button>` : ''}
      </div>

      <!-- (b) Cụm công cụ thao tác -->
      <div class="seat-group seat-group-mid">
        <div class="seat-search-wrap">
          ${seatIcon('search', 18)}
          <input id="seat-search" value="${escH(query)}" placeholder="Tìm học sinh..." />
        </div>
        ${editable ? `<button id="btn-edit" class="seat-btn-edit${editMode ? ' active' : ''}">
          ${editMode ? seatIcon('unlock', 18) + ' Đang sửa' : seatIcon('pencil', 18) + ' Bật sửa'}
        </button>` : ''}
      </div>

      <!-- (c) Cụm tiện ích phụ — icon-only, có tooltip qua title -->
      <div class="seat-group seat-icon-group">
        ${editable ? `<button id="btn-random" class="seat-icon-btn" title="Sắp xếp ngẫu nhiên"${editMode ? '' : ' disabled'}>${seatIcon('shuffle', 18)}</button>` : ''}
        ${editable ? `<button id="btn-swap-side" class="seat-icon-btn" title="Đổi bên toàn bộ (trái ↔ phải, giữ nguyên khoảng cách tới lối đi)"${editMode ? '' : ' disabled'}>${seatIcon('arrowLeftRight', 18)}</button>` : ''}
        ${editable ? `<button id="btn-reset" class="seat-icon-btn" title="Khôi phục vị trí ban đầu"${editMode ? '' : ' disabled'}>${seatIcon('rotateCcw', 18)}</button>` : ''}
        <button id="btn-print" class="seat-icon-btn" title="Xuất file hoặc in A4">${seatIcon('printer', 18)}</button>
      </div>

      <!-- (d) Cụm hành động chính -->
      <div class="seat-group seat-group-actions">
        ${editable ? `<button id="btn-create" class="seat-btn-ghost">${seatIcon('plus', 18)} Tạo mới</button>` : ''}
        ${editable ? `<button id="btn-publish" class="seat-btn-badge${publishConfig.status === 'published' ? ' is-on' : publishConfig.status === 'preview' ? ' is-preview' : ''}">${seatIcon('globe', 18)} Công bố${publishConfig.status === 'published' ? ' ✓' : publishConfig.status === 'preview' ? ' 👁' : ''}</button>` : ''}
        ${editable ? `<button id="btn-save" class="seat-btn-save" title="Sơ đồ tự lưu sau mỗi thay đổi — bấm để lưu ngay">${seatIcon('save', 18)} ${saveStatusLabel()}</button>` : ''}
      </div>
    </div>
  </div>

  <!-- ── Main ── -->
  <div class="seat-main${sidebarCollapsed ? ' sidebar-collapsed' : ''}">
    <!-- Sidebar -->
    <div class="seat-side-col">
      <!-- Nút thu gọn / mở rộng sidebar — luôn hiện, kể cả khi đã collapsed -->
      <button id="btn-sidebar-toggle" class="seat-sidebar-toggle" title="${sidebarCollapsed ? 'Mở rộng sidebar' : 'Thu gọn sidebar'}">
        ${seatIcon(sidebarCollapsed ? 'sidebarExpand' : 'sidebarCollapse', 16)}
        <span>${sidebarCollapsed ? '' : 'Thu gọn'}</span>
      </button>
      ${sidebarCollapsed ? '' : `
      <aside class="seat-students">
        <div class="seat-students-head">
          <div>
            <strong>Danh sách học sinh</strong>
            <span>${unassignedStudents.length === 0 ? 'Tất cả đã có chỗ ngồi' : 'Kéo vào ô ghế để xếp chỗ'}</span>
          </div>
          <span class="seat-badge">${unassignedStudents.length}</span>
        </div>
        <div class="seat-student-list">
          ${filteredStudents.length === 0
            ? (unassignedStudents.length === 0
                ? `<div class="seat-students-note">✓ Tất cả học sinh đã có chỗ ngồi.</div>`
                : `<div class="seat-notif-empty">Không tìm thấy học sinh.</div>`)
            : filteredStudents.map(name => {
                const hit = Boolean(q && seatNorm(name).includes(q));
                const fullN = seatFullName(name);
                return `<div class="seat-student-card${hit ? ' highlight' : ''}" draggable="${editable && editMode}" data-student="${escH(name)}" title="${escH(fullN)}">
                  <span>${escH(name)}</span><small>${escH(fullN !== name ? fullN : 'Chưa xếp')}</small>
                </div>`;
              }).join('')
          }
        </div>
      </aside>`}
    </div>

    <!-- Cột phải: hint + board, stack dọc khi portrait -->
    <div class="seat-board-col">
    <!-- Gợi ý xoay ngang — chỉ hiện khi mobile portrait (CSS @media),
         hiện dạng dải nhỏ phía trên board chứ không thay thế board nữa -->
    <div class="seat-rotate-hint">
      ${seatIcon('rotateCcw', 16)}
      <p><strong>Gợi ý:</strong> Xoay ngang để xem rõ hơn — hoặc cuộn ngang bên dưới.</p>
    </div>

    <!-- Board — fit-to-screen bằng CSS scale, overflow:hidden -->
    <div class="seat-board-wrap">
      <div class="seat-board">
        ${roomConfig.windows.left.map((w, i) => `<div class="seat-room-window left${editable && editMode ? ' room-draggable' : ''}"
          style="top:${w.top}%;height:${w.height}px" data-room-type="window" data-room-side="left" data-room-index="${i}">
          ${editable && editMode ? `<span class="seat-room-resize" data-room-resize="1"></span>` : ''}
        </div>`).join('')}
        ${roomConfig.windows.right.map((w, i) => `<div class="seat-room-window right${editable && editMode ? ' room-draggable' : ''}"
          style="top:${w.top}%;height:${w.height}px" data-room-type="window" data-room-side="right" data-room-index="${i}">
          ${editable && editMode ? `<span class="seat-room-resize" data-room-resize="1"></span>` : ''}
        </div>`).join('')}
        <div class="seat-room-door ${roomConfig.door.side}${editable && editMode ? ' room-draggable' : ''}"
          style="top:${roomConfig.door.top}%;height:${roomConfig.door.height}px" data-room-type="door">
          ${editable && editMode ? `<span class="seat-room-resize" data-room-resize="1"></span>` : ''}
        </div>
        <div class="seat-back-label">CUỐI LỚP</div>
        <div class="seat-layout">
          ${renderSide('left', q)}
          <div class="seat-aisle">LỐI ĐI</div>
          ${renderSide('right', q)}
        </div>
        <div class="seat-front">
          ${roomConfig.front.map((f, i) => `<span class="${(String(f.key).replace(/[^a-zA-Z0-9_-]/g, '') || 'front-slot')}"
            draggable="${editable && editMode}" data-front-index="${i}">
            <span class="seat-front-icon">${seatIcon(f.icon, 15)}</span>
            ${escH(f.label)}
          </span>`).join('')}
        </div>
        <div class="seat-approve">GVCN: Võ Thị Ngọc Tân – Đã Duyệt</div>

        <!-- Modal chỉ che khu vực sơ đồ -->
        ${renderModal(currentTitle, publishConfig)}
      </div>
    </div>
    </div><!-- /seat-board-col -->
  </div>
</div>
`;

  bindEvents();
  scheduleFitBoard();
}

function escH(s) { return String(s ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;'); }

/* ---------- Icon set (SVG inline, quy chuẩn kiểu Lucide) ---------- */
const SEAT_ICON_PATHS = {
  layoutGrid: '<rect width="7" height="7" x="3" y="3" rx="1"/><rect width="7" height="7" x="14" y="3" rx="1"/><rect width="7" height="7" x="14" y="14" rx="1"/><rect width="7" height="7" x="3" y="14" rx="1"/>',
  chevronDown: '<path d="m6 9 6 6 6-6"/>',
  chevronRight: '<path d="m9 18 6-6-6-6"/>',
  chevronLeft: '<path d="m15 18-6-6 6-6"/>',
  desk: '<rect x="2" y="7" width="20" height="3" rx="1"/><path d="M6 10v7M18 10v7"/><path d="M4 17h16"/>',
  blackboard: '<rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/>',
  doorOpen: '<path d="M13 4h3a2 2 0 0 1 2 2v14"/><path d="M2 20h3"/><path d="M13 20h9"/><path d="M10 12v.01"/><path d="M13 4l-6 2v14l6 2V4z"/>',
  sidebarCollapse: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m16 15-3-3 3-3"/>',
  sidebarExpand: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M9 3v18"/><path d="m14 9 3 3-3 3"/>',
  settings: '<path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/>',
  search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
  pencil: '<path d="M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z"/><path d="m15 5 4 4"/>',
  unlock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 9.9-1"/>',
  lockClosed: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
  shuffle: '<path d="m18 14 4 4-4 4"/><path d="m18 2 4 4-4 4"/><path d="M2 18h1.973a4 4 0 0 0 3.3-1.7l5.454-8.6a4 4 0 0 1 3.3-1.7H22"/><path d="M2 6h1.972a4 4 0 0 1 3.6 2.2"/><path d="M22 18h-6.041a4 4 0 0 1-3.3-1.8l-.359-.45"/>',
  arrowLeftRight: '<path d="m16 3 4 4-4 4"/><path d="M4 7h16"/><path d="m8 21-4-4 4-4"/><path d="M20 17H4"/>',
  rotateCcw: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/>',
  printer: '<polyline points="6 9 6 2 18 2 18 9"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/>',
  plus: '<path d="M5 12h14"/><path d="M12 5v14"/>',
  globe: '<circle cx="12" cy="12" r="10"/><path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20"/><path d="M2 12h20"/>',
  save: '<path d="M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z"/><path d="M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7"/><path d="M7 3v4a1 1 0 0 0 1 1h7"/>',
  layers: '<path d="m12.83 2.18a2 2 0 0 0-1.66 0L2.6 6.08a1 1 0 0 0 0 1.83l8.58 3.91a2 2 0 0 0 1.66 0l8.58-3.9a1 1 0 0 0 0-1.83Z"/><path d="M2 12a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 12"/><path d="M2 17a1 1 0 0 0 .58.91l8.6 3.91a2 2 0 0 0 1.65 0l8.58-3.9A1 1 0 0 0 22 17"/>',
  copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
  trash2: '<path d="M3 6h18"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><line x1="10" y1="11" x2="10" y2="17"/><line x1="14" y1="11" x2="14" y2="17"/>',
};
function seatIcon(name, size = 18) {
  const body = SEAT_ICON_PATHS[name] || '';
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">${body}</svg>`;
}

// Man hinh chan xem - hien cho nguoi khong phai GVCN/lop truong khi so do
// dang o trang thai rieng tu (chua cong bo).
function renderSeatBlocked(_status) {
  return `<div class="seat-app">
    <div class="seat-blocked">
      <div class="seat-blocked-card">
        <div class="seat-blocked-icon">🔒</div>
        <h2>Sơ đồ lớp chưa được công bố</h2>
        <p>Sơ đồ chỗ ngồi đang ở chế độ riêng tư. Chỉ GVCN mới xem/sửa được lúc này — vui lòng quay lại sau khi sơ đồ được công bố.</p>
        <p class="seat-blocked-countdown">Tự động kiểm tra lại sau <b id="seat-blocked-countdown-num">${seatAccessCountdown}</b>s…</p>
      </div>
    </div>
  </div>`;
}


function renderSide(side, q) {
  return `<div class="seat-side" data-side="${side}">
    ${seatState[side].map((row, rowIdx) => `
      <div class="seat-row">
        ${row.map((name, seatIdx) => {
          const hit = Boolean(q && name && seatNorm(name).includes(q));
          // So khớp cả tên ngắn lẫn full-name với userName (tên đầy đủ trong session)
          const isSelf = Boolean(userName && name && (
            seatNorm(name) === seatNorm(userName) ||
            seatNorm(seatFullName(name)) === seatNorm(userName)
          ));
          const isLocked = Boolean(name && lockedStudents.has(name));
          const editableHere = canEditSeating() && editMode;
          const cls = [
            'seat-cell',
            name ? '' : 'empty',
            hit ? 'highlight' : '',
            isSelf ? 'self-seat' : '',
            isLocked ? 'locked' : '',
          ].filter(Boolean).join(' ');
          const fullName = name ? seatFullName(name) : '';
          return `<div class="${cls}"
            draggable="${editableHere && !isLocked}"
            data-side="${side}" data-row="${rowIdx}" data-seat="${seatIdx}">
            ${isSelf ? '<span class="seat-you-badge">Bạn</span>' : ''}
            ${editableHere && name ? `<button type="button" class="seat-lock-btn${isLocked ? ' is-locked' : ''}"
              data-lock-toggle="${escH(name)}" draggable="false"
              title="${isLocked ? 'Bỏ khoá chỗ ngồi' : 'Khoá chỗ ngồi (giữ nguyên khi random)'}">
              ${seatIcon(isLocked ? 'lockClosed' : 'unlock', 12)}
            </button>` : ''}
            <span class="seat-short-name">${escH(name || 'Trống')}</span>
            ${fullName && fullName !== name ? `<span class="seat-full-name">${escH(fullName)}</span>` : ''}
          </div>`;
        }).join('')}
      </div>`).join('')}
  </div>`;
}

function renderModal(currentTitle, publishConfig) {
  if (!modal) return '';
  const isPublished = publishConfig.status === 'published';

  if (modal === 'create') {
    const suggested = `Sơ đồ ${sheets.length + 1}`;
    return `<div class="seat-modal-backdrop" id="modal-backdrop">
      <div class="seat-modal">
        <div>
          <h3>Tạo sơ đồ mới</h3>
          <p>Sơ đồ mới sẽ mặc định ở chế độ Riêng tư cho đến khi bạn công bố.</p>
        </div>
        <label>Tên sơ đồ mới
          <input id="modal-title-input" value="${escH(suggested)}" maxlength="60" />
        </label>
        <div class="seat-modal-actions">
          <button id="modal-cancel">Huỷ</button>
          <button class="primary" id="modal-confirm">Tạo sơ đồ</button>
        </div>
      </div>
    </div>`;
  }

  if (modal === 'publish') {
    const curStatus = publishConfig.status || 'private';
    const previewStudents = publishConfig.previewStudents || publishConfig.preview_students || '';
    // Render danh sách checkbox học sinh để chọn xem trước
    const previewList = previewStudents.split(',').map(n => seatNorm(n.trim())).filter(Boolean);
    const studentChecks = SEAT_STUDENTS.map(name => {
      const checked = previewList.includes(seatNorm(name));
      const fullN = seatFullName(name);
      return `<label class="seat-preview-check-label" title="${escH(fullN)}">
        <input type="checkbox" class="seat-preview-student-cb" value="${escH(name)}"${checked ? ' checked' : ''}>
        <span>${escH(name)}</span>${fullN !== name ? `<small class="seat-preview-full">${escH(fullN)}</small>` : ''}
      </label>`;
    }).join('');

    return `<div class="seat-modal-backdrop" id="modal-backdrop">
      <div class="seat-modal seat-modal-publish">
        <div>
          <h3>Cài đặt công bố sơ đồ</h3>
          <p>${escH(currentTitle)}</p>
        </div>
        <label>Trạng thái
          <select id="modal-publish-select">
            <option value="private"${curStatus === 'private' ? ' selected' : ''}>🔒 Riêng tư</option>
            <option value="preview"${curStatus === 'preview' ? ' selected' : ''}>👁 Xem trước (học sinh được chọn)</option>
            <option value="published"${curStatus === 'published' ? ' selected' : ''}>🌐 Công bố cho cả lớp</option>
          </select>
        </label>
        <div id="modal-preview-section" class="${curStatus !== 'preview' ? 'seat-hidden' : ''}">
          <div class="seat-preview-section-head">
            <span>Học sinh được xem trước</span>
            <div class="seat-preview-section-actions">
              <button type="button" id="btn-preview-all">Chọn tất cả</button>
              <button type="button" id="btn-preview-none">Bỏ chọn</button>
            </div>
          </div>
          <div class="seat-preview-student-grid" id="modal-preview-grid">
            ${studentChecks}
          </div>
        </div>
        <div class="seat-modal-actions">
          <button id="modal-cancel">Huỷ</button>
          <button class="primary" id="modal-confirm">Lưu cài đặt</button>
        </div>
      </div>
    </div>`;
  }

  if (modal === 'manage') {
    const curStatus = publishConfig.status || 'private';
    const previewStudents = publishConfig.previewStudents || publishConfig.preview_students || '';
    const previewCount = previewStudents.split(',').map(n => n.trim()).filter(Boolean).length;
    const statusLabel = curStatus === 'published' ? 'Đã công bố' : curStatus === 'preview' ? 'Xem trước' : 'Riêng tư';
    const statusDesc  = curStatus === 'published' ? 'Cả lớp có thể xem sơ đồ này'
      : curStatus === 'preview' ? `${previewCount} học sinh đang được xem trước`
      : 'Chỉ GVCN/cán bộ lớp xem được';
    const pillClass   = curStatus === 'published' ? 'published' : curStatus === 'preview' ? 'preview' : 'private';
    return `<div class="seat-modal-backdrop" id="modal-backdrop">
      <div class="seat-modal">
        <div>
          <h3>Quản lý công bố</h3>
          <p>${escH(currentTitle)}</p>
        </div>
        <div class="seat-status-row">
          <div>
            <strong>Trạng thái hiện tại</strong>
            <span>${statusDesc}</span>
          </div>
          <span class="seat-status-pill ${pillClass}">${statusLabel}</span>
        </div>
        <div class="seat-modal-manage-actions">
          <button class="seat-mini-btn" id="modal-edit-settings">Sửa cài đặt</button>
          <button class="seat-mini-btn primary" id="modal-toggle">${curStatus === 'published' ? 'Đưa về riêng tư' : 'Công bố ngay'}</button>
        </div>
        <div class="seat-room-form">
          <strong>Đổi nhãn BÀN GV / BẢNG / CỬA RA VÀO</strong>
          <p class="seat-room-hint">Muốn đổi <b>vị trí/kích thước</b>? Đóng cửa sổ này, bấm "Bật sửa" rồi kéo-thả hoặc kéo giãn cửa sổ/cửa ngay trên sơ đồ.</p>
          ${roomConfig.front.map((f, i) => `<label>Nhãn ô ${i === 0 ? 'bàn GV' : i === 1 ? 'bảng' : 'cửa'}
            <input type="text" id="room-front-${i}" value="${escH(f.label)}" maxlength="24" />
          </label>`).join('')}
          <button class="seat-mini-btn" id="modal-room-save">Lưu nhãn</button>
        </div>
        <div class="seat-modal-actions">
          <button id="modal-cancel">Đóng</button>
        </div>
      </div>
    </div>`;
  }

  if (modal === 'sheets') {
    return `<div class="seat-modal-backdrop" id="modal-backdrop">
      <div class="seat-modal seat-modal-sheets">
        <div>
          <h3>Quản lý sơ đồ</h3>
          <p>Đổi tên, sao chép hoặc xoá các sơ đồ đã tạo cho lớp.</p>
        </div>
        <div class="seat-sheets-list">
          ${sheets.map(item => `
            <div class="seat-sheets-row" data-sheet-row="${escH(item.id)}">
              <div class="seat-sheets-row-info">
                <input type="text" class="seat-sheets-rename-input" data-rename-id="${escH(item.id)}"
                  value="${escH(item.title || '')}" maxlength="60" />
                ${item.id === currentId ? '<span class="seat-badge-current">Đang mở</span>' : ''}
              </div>
              <div class="seat-sheets-row-actions">
                <button type="button" class="seat-mini-btn" data-open-id="${escH(item.id)}" title="Mở sơ đồ này"${item.id === currentId ? ' disabled' : ''}>${seatIcon('layoutGrid', 15)}</button>
                <button type="button" class="seat-mini-btn" data-dup-id="${escH(item.id)}" title="Sao chép">${seatIcon('copy', 15)}</button>
                <button type="button" class="seat-mini-btn danger" data-del-id="${escH(item.id)}" title="Xoá"${sheets.length <= 1 ? ' disabled' : ''}>${seatIcon('trash2', 15)}</button>
              </div>
            </div>`).join('')}
        </div>
        <div class="seat-modal-actions">
          <button id="modal-sheets-add">${seatIcon('plus', 16)} Tạo sơ đồ mới</button>
          <button id="modal-cancel">Đóng</button>
        </div>
      </div>
    </div>`;
  }

  return '';
}


/* ============================================================
   PRINT / XUẤT A4 — port từ seatingPrintExportA4.ts
   ============================================================ */
const PRINT_MODAL_ID = 'a3k64-seat-print-modal';

function printTodayText() {
  const now = new Date();
  return `${String(now.getDate()).padStart(2,'0')}/${String(now.getMonth()+1).padStart(2,'0')}/${now.getFullYear()}`;
}

function printCurrentSeats() {
  // Đọc từ seatState (luôn có, không cần DOM fallback)
  const norm = (rows) => Array.from({length:7},(_,ri)=>{
    const row = Array.isArray(rows?.[ri]) ? rows[ri] : [];
    return Array.from({length:4},(_,si)=>String(row[si]||'').trim());
  });
  return { left: norm(seatState.left), right: norm(seatState.right) };
}

function printCell(name) {
  const clean = String(name||'').trim();
  const display = clean || 'Ø';
  const len = clean.length;
  const cls = len >= 12 ? 'tiny' : len >= 9 ? 'small' : '';
  return `<td class="${cls}"><span>${escH(display)}</span></td>`;
}

function printSide(rows) {
  return `<div class="side">${rows.map(row=>`<table class="desk"><tr>${row.map(printCell).join('')}</tr></table>`).join('')}</div>`;
}

function printBuildHtml(seats, changeNo, dateText) {
  const no   = escH(changeNo   || '...');
  const date = escH(dateText   || '.../.../...');
  // Lấy nhãn BÀN GV / BẢNG / CỬA RA VÀO từ roomConfig hiện tại
  const frontLabels = roomConfig.front.map(f => escH(f.label));
  while (frontLabels.length < 3) frontLabels.push('');

  // ── Vị trí cửa sổ / cửa: LẤY TỪ roomConfig HIỆN TẠI (đồng bộ với sơ đồ
  // trên màn hình — kể cả khi người dùng đã "Bật sửa" rồi kéo/đổi bên).
  // Quy đổi px→mm theo đúng tỉ lệ mặc định (26mm/90px cho cửa sổ,
  // 34mm/108px cho cửa) để giữ nguyên tỉ lệ hình ảnh cũ khi dùng giá trị mặc định.
  const WIN_MM_PER_PX  = 26 / 90;
  const DOOR_MM_PER_PX = 34 / 108;

  function windowDivs(side) {
    const list = (roomConfig.windows && roomConfig.windows[side]) || [];
    return list.map(w => {
      const top    = clampNum(w.top, 2, 96, 10);
      const height = clampNum(w.height, 30, 260, 90);
      const heightMm = (height * WIN_MM_PER_PX).toFixed(2);
      return `<div class="window ${side}" style="top:${top}%;height:${heightMm}mm;"></div>`;
    }).join('');
  }

  const doorCfg    = roomConfig.door || SEAT_DEFAULT_ROOM.door;
  const doorSide   = doorCfg.side === 'left' ? 'left' : 'right';
  const doorTop    = clampNum(doorCfg.top, 2, 96, 74);
  const doorHeight = clampNum(doorCfg.height, 30, 260, 108);
  const doorHeightMm = (doorHeight * DOOR_MM_PER_PX).toFixed(2);
  const doorDiv = `<div class="door ${doorSide}" style="top:${doorTop}%;height:${doorHeightMm}mm;"></div>`;

  return `<!doctype html>
<html lang="vi">
<head>
<meta charset="utf-8"/>
<title>Sơ đồ chỗ ngồi lớp 12A3</title>
<style>
  @page{size:A4 landscape;margin:7mm 9mm;}
  *{box-sizing:border-box;}
  html,body{margin:0;padding:0;background:#fff;color:#000;font-family:"Times New Roman","Noto Serif",Arial,serif;}
  body{width:279mm;min-height:192mm;}
  .page{width:100%;min-height:192mm;position:relative;padding:6mm 7mm 7mm;}
  .title{text-align:center;color:red;font-size:19pt;font-weight:700;margin:0 0 3.5mm;text-transform:uppercase;}
  .subtitle{text-align:center;color:red;font-size:15.5pt;font-weight:700;margin:0 0 2mm;}
  .room{position:relative;border:1.8px solid #0f3554;min-height:148mm;padding:12mm 10mm 9mm;}
  .back{position:absolute;top:4mm;left:50%;transform:translateX(-50%);font-size:14pt;font-weight:700;}
  .layout{display:grid;grid-template-columns:minmax(0,1fr) 23mm minmax(0,1fr);gap:12mm;align-items:stretch;margin-top:1mm;}
  .side{display:grid;grid-template-rows:repeat(7,1fr);gap:8.8mm;align-content:stretch;min-width:0;}
  .desk{width:100%;height:8.8mm;border-collapse:collapse;table-layout:fixed;font-size:12.4pt;}
  .desk td{border:1px solid #000;text-align:center;vertical-align:middle;height:8.8mm;width:25%;padding:0 1.1mm;white-space:nowrap;line-height:1.05;overflow:hidden;}
  .desk td span{display:block;width:100%;overflow:hidden;text-overflow:clip;white-space:nowrap;}
  .desk td.small{font-size:11.4pt;letter-spacing:-.02em;}
  .desk td.tiny{font-size:10.3pt;letter-spacing:-.04em;}
  .aisle{display:flex;align-items:flex-end;justify-content:center;font-size:13pt;font-weight:700;padding-bottom:1mm;}
  .front{display:grid;grid-template-columns:minmax(0,1fr) 23mm minmax(0,1fr);gap:12mm;margin-top:2mm;font-size:14pt;font-weight:700;}
  .front span{text-align:center;}
  .gv{position:absolute;right:8mm;bottom:2mm;font-size:13.2pt;}
  .window{position:absolute;width:5mm;background:#176a8b;border:1.3px solid #08384d;}
  .window.left{left:-2.7mm;}
  .window.right{right:-2.7mm;}
  .door{position:absolute;width:5mm;background:#050505;border:1.3px solid #050505;}
  .door.left{left:-2.7mm;}
  .door.right{right:-2.7mm;}
  @media print{.page{break-inside:avoid;}body{-webkit-print-color-adjust:exact;print-color-adjust:exact;}}
</style>
</head>
<body>
  <main class="page">
    <h1 class="title">SƠ ĐỒ CHỖ NGỒI LỚP 12A3</h1>
    <h2 class="subtitle">Thay đổi lần ${no} – Áp dụng từ ngày ${date}</h2>
    <section class="room">
      ${windowDivs('left')}
      ${windowDivs('right')}
      ${doorDiv}
      <div class="back">CUỐI LỚP</div>
      <div class="layout">
        ${printSide(seats.left)}
        <div class="aisle"></div>
        ${printSide(seats.right)}
      </div>
      <div class="front">
        <span>${frontLabels[0]||'BÀN GV'}</span>
        <span>${frontLabels[1]||'BẢNG'}</span>
        <span>${frontLabels[2]||'CỬA RA VÀO'}</span>
      </div>
      <div class="gv">GVCN: Võ Thị Ngọc Tân – Đã duyệt</div>
    </section>
  </main>
  <script>window.addEventListener('load',()=>setTimeout(()=>window.print(),120));<\/script>
</body>
</html>`;
}

function printOpenWindow(changeNo, dateText) {
  const seats = printCurrentSeats();
  const html  = printBuildHtml(seats, changeNo, dateText);
  const win   = window.open('', '_blank', 'width=1200,height=820');
  if (!win) {
    // Popup bị chặn → fallback tải file
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url  = URL.createObjectURL(blob);
    const a    = document.createElement('a');
    a.href = url; a.download = 'so-do-cho-ngoi-12A3.html'; a.click();
    setTimeout(() => URL.revokeObjectURL(url), 3000);
    return;
  }
  win.document.open();
  win.document.write(html);
  win.document.close();
}

function showPrintModal() {
  // Xoá modal cũ nếu còn
  document.getElementById(PRINT_MODAL_ID)?.remove();

  // Inject style modal một lần
  if (!document.getElementById('a3k64-print-modal-style')) {
    const s = document.createElement('style');
    s.id = 'a3k64-print-modal-style';
    s.textContent = `
      #${PRINT_MODAL_ID}{position:fixed;inset:0;z-index:99999;background:rgba(15,23,42,.45);display:grid;place-items:center;padding:20px;font-family:var(--seat-font,system-ui,sans-serif);}
      #${PRINT_MODAL_ID} .pm-card{width:min(480px,calc(100vw - 32px));background:var(--seat-card-bg,#111827);border:1px solid var(--seat-border,#263244);border-radius:20px;box-shadow:0 32px 80px rgba(0,0,0,.5);padding:24px;color:var(--seat-text,#f8fafc);}
      #${PRINT_MODAL_ID} h3{margin:0 0 5px;font-size:18px;font-weight:800;letter-spacing:-.02em;}
      #${PRINT_MODAL_ID} p{margin:0 0 18px;color:var(--seat-text-muted,#94a3b8);font-size:12.5px;}
      #${PRINT_MODAL_ID} .pm-grid{display:grid;grid-template-columns:.6fr 1fr;gap:11px;margin-bottom:18px;}
      #${PRINT_MODAL_ID} label{display:grid;gap:5px;font-size:11px;font-weight:700;color:var(--seat-text-muted,#94a3b8);text-transform:uppercase;letter-spacing:.06em;}
      #${PRINT_MODAL_ID} input{height:40px;border:1px solid var(--seat-border,#263244);border-radius:11px;padding:0 12px;font-size:14px;font-weight:700;color:var(--seat-text,#f8fafc);background:var(--seat-input-bg,#0f172a);outline:none;width:100%;}
      #${PRINT_MODAL_ID} input:focus{border-color:var(--seat-accent,#2563eb);box-shadow:0 0 0 3px color-mix(in srgb,var(--seat-accent,#2563eb) 20%,transparent);}
      #${PRINT_MODAL_ID} .pm-actions{display:flex;justify-content:flex-end;gap:8px;}
      #${PRINT_MODAL_ID} .pm-btn{height:40px;border:1px solid var(--seat-border,#263244);border-radius:11px;padding:0 16px;background:var(--seat-card-bg,#111827);color:var(--seat-text,#f8fafc);font-weight:700;font-size:13px;cursor:pointer;font-family:inherit;}
      #${PRINT_MODAL_ID} .pm-btn.primary{background:var(--seat-accent,#2563eb);border-color:transparent;color:#fff;}
      #${PRINT_MODAL_ID} .pm-btn:hover{opacity:.88;}
      @media(max-width:480px){#${PRINT_MODAL_ID} .pm-grid{grid-template-columns:1fr;}}
    `;
    document.head.appendChild(s);
  }

  const wrap = document.createElement('div');
  wrap.id = PRINT_MODAL_ID;
  wrap.innerHTML = `
    <div class="pm-card" role="dialog" aria-modal="true" aria-label="In sơ đồ chỗ ngồi">
      <h3>In / Xuất sơ đồ A4</h3>
      <p>Khổ A4 ngang · Lớp 12A3 · Times New Roman</p>
      <div class="pm-grid">
        <label>Thay đổi lần
          <input id="pm-change-no" type="text" inputmode="numeric" value="1" placeholder="1" />
        </label>
        <label>Áp dụng từ ngày
          <input id="pm-change-date" type="text" value="${printTodayText()}" placeholder="dd/mm/yyyy" />
        </label>
      </div>
      <div class="pm-actions">
        <button class="pm-btn" id="pm-cancel">Huỷ</button>
        <button class="pm-btn primary" id="pm-print">🖨 In A4 ngang</button>
      </div>
    </div>`;
  document.body.appendChild(wrap);

  // Bind events
  document.getElementById('pm-cancel').onclick = () => wrap.remove();
  wrap.addEventListener('click', e => { if (e.target === wrap) wrap.remove(); });
  document.getElementById('pm-print').onclick = () => {
    const changeNo  = (document.getElementById('pm-change-no').value  || '').trim();
    const dateText  = (document.getElementById('pm-change-date').value || '').trim();
    wrap.remove();
    printOpenWindow(changeNo, dateText);
  };

  // Focus ô số lần thay đổi
  setTimeout(() => document.getElementById('pm-change-no')?.select(), 60);
}

/* ---------- Bind events after each render ---------- */
function bindEvents() {
  /* sidebar toggle */
  on('btn-sidebar-toggle', () => { sidebarCollapsed = !sidebarCollapsed; render(); });
  on('btn-mobile-tools-toggle', () => { mobileToolsOpen = !mobileToolsOpen; render(); });

  /* toolbar */
  on('btn-publish',  () => openModal('publish'));
  on('btn-manage',   () => openModal('manage'));
  on('btn-manage-sheets', () => openModal('sheets'));
  on('btn-save',     () => handleSaveSheet(false));
  on('btn-create',   () => openModal('create'));
  on('btn-edit',     () => { editMode = !editMode; render(); });
  on('btn-reset',    handleReset);
  on('btn-random',   handleRandom);
  on('btn-swap-side', handleSwapSide);
  on('btn-print',    () => showPrintModal());

  /* search — patch-only để tránh mất focus sau mỗi ký tự */
  const searchEl = document.getElementById('seat-search');
  if (searchEl) searchEl.addEventListener('input', e => {
    query = e.target.value;
    const q2 = seatNorm(query);

    // 1. Cập nhật danh sách học sinh chưa xếp trong sidebar
    const listEl = document.querySelector('.seat-student-list');
    if (listEl) {
      const unassigned = SEAT_STUDENTS.filter(n => !findSeat(seatState, n));
      const filtered   = unassigned.filter(n => !q2 || seatNorm(n).includes(q2));
      if (filtered.length === 0) {
        listEl.innerHTML = unassigned.length === 0
          ? `<div class="seat-students-note">✓ Tất cả học sinh đã có chỗ ngồi.</div>`
          : `<div class="seat-notif-empty">Không tìm thấy học sinh.</div>`;
      } else {
        const editable2 = canEditSeating();
        listEl.innerHTML = filtered.map(name => {
          const hit   = Boolean(q2 && seatNorm(name).includes(q2));
          const fullN = seatFullName(name);
          return `<div class="seat-student-card${hit ? ' highlight' : ''}" draggable="${editable2 && editMode}" data-student="${escH(name)}" title="${escH(fullN)}">
            <span>${escH(name)}</span><small>${escH(fullN !== name ? fullN : 'Chưa xếp')}</small>
          </div>`;
        }).join('');
        // Gắn lại drag cho các card vừa tạo
        listEl.querySelectorAll('[data-student]').forEach(card => {
          card.addEventListener('dragstart', () => {
            dragPayload = { type: 'student', name: card.dataset.student };
          });
        });
      }
    }

    // 2. Cập nhật highlight trên sơ đồ (thêm/bỏ class, không tạo lại DOM)
    document.querySelectorAll('[data-side][data-row][data-seat]').forEach(cell => {
      const pos  = { side: cell.dataset.side, row: +cell.dataset.row, seat: +cell.dataset.seat };
      const name = seatAt(seatState, pos);
      const hit  = Boolean(q2 && name && seatNorm(name).includes(q2));
      cell.classList.toggle('highlight', hit);
    });
  });

  /* sheet dropdown */
  on('btn-sheet-trigger', e => { e.stopPropagation(); selectOpen = !selectOpen; render(); });
  document.querySelectorAll('[data-sheet-id]').forEach(btn => {
    btn.addEventListener('click', e => {
      e.stopPropagation();
      selectOpen = false;
      const id = btn.dataset.sheetId;
      const item = sheets.find(i => i.id === id);
      if (item) applySheet(item);
    });
  });

  /* close dropdown on outside click */
  document.addEventListener('click', closeSelect, { once: true });

  /* nút khoá/mở khoá chỗ ngồi từng học sinh */
  document.querySelectorAll('[data-lock-toggle]').forEach(btn => {
    btn.addEventListener('mousedown', e => e.stopPropagation());
    btn.addEventListener('click', e => {
      e.preventDefault();
      e.stopPropagation();
      handleToggleLock(btn.dataset.lockToggle);
    });
  });

  /* drag-and-drop — student cards (chỉ khi editMode) */
  if (editMode) {
  document.querySelectorAll('[data-student]').forEach(card => {
    card.addEventListener('dragstart', () => {
      dragPayload = { type: 'student', name: card.dataset.student };
    });
  });
  }

  /* Kéo học sinh TỪ ghế ra lại danh sách "Danh sách học sinh" → bỏ chỗ ngồi
     (trả về chưa xếp). Gắn drop-zone lên cả khung sidebar lẫn danh sách bên
     trong, vì .seat-student-list có thể trống (không có gì để nhận sự kiện
     nếu chỉ gắn lên chính nó lúc danh sách rỗng). */
  if (editMode) {
    const unassignZones = [
      document.querySelector('.seat-student-list'),
      document.querySelector('.seat-students'),
    ].filter(Boolean);
    unassignZones.forEach(zone => {
      zone.addEventListener('dragover', e => {
        if (!dragPayload || dragPayload.type !== 'seat') return;
        e.preventDefault();
        zone.classList.add('drag-over');
      });
      zone.addEventListener('dragleave', () => zone.classList.remove('drag-over'));
      zone.addEventListener('drop', e => {
        e.preventDefault();
        zone.classList.remove('drag-over');
        handleUnassignDrop();
      });
    });
  }

  /* ── Mobile touch: cuộn + long-press xem tên đầy đủ ─────────────────────
     Vấn đề gốc:
     1. Trên touch device, browser hiểu touchstart trên element có draggable="true"
        là "muốn drag" → chặn scroll của .seat-board-wrap.
     2. :hover dính lại sau tap → full-name tooltip hiện liên tục.
     Fix:
     - Khi KHÔNG ở editMode: bỏ draggable, dùng touch-action:pan-x pan-y để
       browser tự lo scroll, không cần preventDefault().
     - Long-press (≥400ms) → thêm .show-full → CSS hiện full-name → tự xoá sau 1.5s.
  ─────────────────────────────────────────────────────────────────────────── */
  const isTouchDevice = window.matchMedia('(hover:none)').matches || navigator.maxTouchPoints > 0;

  document.querySelectorAll('[data-side][data-row]').forEach(cell => {
    // Chế độ không sửa: bỏ draggable hoàn toàn để touch scroll hoạt động
    if (!editMode) {
      cell.removeAttribute('draggable');
      cell.style.touchAction = 'pan-x pan-y';
    }

    if (isTouchDevice && !editMode) {
      let pressTimer = null;
      let moved = false;
      let startX = 0, startY = 0;

      cell.addEventListener('touchstart', e => {
        moved = false;
        startX = e.touches[0].clientX;
        startY = e.touches[0].clientY;
        pressTimer = setTimeout(() => {
          if (!moved) {
            cell.classList.add('show-full');
            setTimeout(() => cell.classList.remove('show-full'), 1500);
          }
        }, 400);
      }, { passive: true });

      cell.addEventListener('touchmove', e => {
        const dx = Math.abs(e.touches[0].clientX - startX);
        const dy = Math.abs(e.touches[0].clientY - startY);
        if (dx > 6 || dy > 6) {
          moved = true;
          clearTimeout(pressTimer);
        }
      }, { passive: true });

      cell.addEventListener('touchend', () => {
        clearTimeout(pressTimer);
      }, { passive: true });
    }
  });

  /* drag-and-drop — seat cells (chỉ gắn khi editMode) */
  if (editMode) {
  document.querySelectorAll('[data-side][data-row]').forEach(cell => {
    const pos = { side: cell.dataset.side, row: +cell.dataset.row, seat: +cell.dataset.seat };
    cell.addEventListener('dragstart', () => {
      dragPayload = { type: 'seat', pos, name: seatAt(seatState, pos) };
    });
    cell.addEventListener('dragover', e => { e.preventDefault(); cell.classList.add('drag-over'); });
    cell.addEventListener('dragleave', () => cell.classList.remove('drag-over'));
    cell.addEventListener('drop', e => {
      e.preventDefault();
      cell.classList.remove('drag-over');
      handleDrop(pos);
    });
  });

  /* drag-and-drop — hàng BÀN GV / BẢNG / CỬA RA VÀO (đổi chỗ như xếp hình) */
  document.querySelectorAll('[data-front-index]').forEach(el => {
    const idx = +el.dataset.frontIndex;
    el.addEventListener('dragstart', () => { dragFrontIndex = idx; });
    el.addEventListener('dragover', e => { e.preventDefault(); el.classList.add('drag-over'); });
    el.addEventListener('dragleave', () => el.classList.remove('drag-over'));
    el.addEventListener('drop', e => {
      e.preventDefault();
      el.classList.remove('drag-over');
      handleFrontDrop(idx);
    });
  });

  /* kéo tự do cửa sổ/cửa bằng chuột (đổi vị trí + kích thước, không cần thiết lập thủ công) */
  document.querySelectorAll('[data-room-type]').forEach(el => {
    el.addEventListener('mousedown', e => {
      if (e.target.closest('[data-room-resize]')) return;
      startRoomMove(e, el);
    });
  });
  document.querySelectorAll('[data-room-resize]').forEach(handle => {
    handle.addEventListener('mousedown', e => { e.stopPropagation(); startRoomResize(e, handle); });
  });
  } // end if (editMode)

  /* modals */
  const backdrop = document.getElementById('modal-backdrop');
  if (backdrop) {
    backdrop.addEventListener('click', e => { if (e.target === backdrop) closeModal(); });
    // Mới mở (openModal vừa gọi render()) → đợi 2 khung hình để trình duyệt
    // "chốt" trạng thái opacity:0 ban đầu rồi mới thêm is-open, để transition
    // opacity thật sự chạy (fade mượt) thay vì nhảy thẳng luôn opacity:1.
    // Re-render trong lúc modal đang mở sẵn (vd đổi trạng thái công bố) →
    // giữ nguyên trạng thái đang mở, không phát lại hiệu ứng fade.
    if (modalOpening) {
      modalOpening = false;
      requestAnimationFrame(() => requestAnimationFrame(() => backdrop.classList.add('is-open')));
    } else {
      backdrop.classList.add('is-open');
    }
  }

  on('modal-cancel', closeModal);

  if (modal === 'create') {
    const inp = document.getElementById('modal-title-input');
    if (inp) { inp.focus(); inp.select(); }
    if (inp) inp.addEventListener('keydown', e => { if (e.key === 'Enter') doCreateSheet(); });
    on('modal-confirm', doCreateSheet);
  }

  if (modal === 'publish') {
    // Ẩn/hiện danh sách học sinh khi chọn trạng thái
    const publishSel = document.getElementById('modal-publish-select');
    const previewSection = document.getElementById('modal-preview-section');
    if (publishSel && previewSection) {
      publishSel.addEventListener('change', () => {
        previewSection.classList.toggle('seat-hidden', publishSel.value !== 'preview');
      });
    }
    // Chọn / bỏ chọn tất cả
    on('btn-preview-all', () => {
      document.querySelectorAll('.seat-preview-student-cb').forEach(cb => { cb.checked = true; });
    });
    on('btn-preview-none', () => {
      document.querySelectorAll('.seat-preview-student-cb').forEach(cb => { cb.checked = false; });
    });

    on('modal-confirm', async () => {
      const sel = document.getElementById('modal-publish-select');
      if (!sel) return;
      const status = sel.value;
      let previewStudents = '';
      if (status === 'preview') {
        const checked = [...document.querySelectorAll('.seat-preview-student-cb:checked')];
        previewStudents = checked.map(cb => cb.value).join(',');
        if (!previewStudents) {
          showToast('Chọn ít nhất một học sinh để dùng chế độ Xem trước.', 'warn');
          return;
        }
      }
      await setPublishStatus(status, previewStudents);
      closeModal();
    });
  }

  if (modal === 'manage') {
    on('modal-edit-settings', () => openModal('publish'));
    on('modal-toggle', async () => {
      const next = publishConfig.status === 'published' ? 'private' : 'published';
      await setPublishStatus(next);
      closeModal();
    });
    on('modal-room-save', async () => {
      if (!canEditSeating()) { showToast('Bạn không có quyền sửa nhãn.', 'error'); return; }
      const next = cloneRoom(roomConfig);
      roomConfig.front.forEach((f, i) => {
        const inp = document.getElementById(`room-front-${i}`);
        next.front[i].label = (inp?.value || '').trim() || f.label;
      });
      roomConfig = normalizeRoom(next);
      await handleSaveRoomConfig();
      closeModal();
    });
  }

  if (modal === 'sheets') {
    // Đổi tên — lưu khi rời khỏi ô nhập (blur) hoặc bấm Enter, không cần nút riêng.
    document.querySelectorAll('.seat-sheets-rename-input').forEach(inp => {
      const commit = () => doRenameSheet(inp.dataset.renameId, inp.value);
      inp.addEventListener('blur', commit);
      inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); inp.blur(); } });
    });
    document.querySelectorAll('[data-open-id]').forEach(btn => {
      btn.addEventListener('click', () => {
        const item = sheets.find(i => i.id === btn.dataset.openId);
        if (item) { closeModal(); applySheet(item); }
      });
    });
    document.querySelectorAll('[data-dup-id]').forEach(btn => {
      btn.addEventListener('click', () => doDuplicateSheet(btn.dataset.dupId));
    });
    document.querySelectorAll('[data-del-id]').forEach(btn => {
      btn.addEventListener('click', () => doDeleteSheet(btn.dataset.delId));
    });
    on('modal-sheets-add', () => openModal('create'));
  }
}

async function setPublishStatus(status, previewStudents) {
  if (!canEditSeating()) { showToast('Bạn không có quyền công bố sơ đồ.', 'error'); return; }
  const title = sheets.find(i => i.id === currentId)?.title || 'Sơ đồ 1';

  if (dataSource === 'gas') {
    // "Công bố" thao tác trên 1 dòng THẬT trong sheet SEATING CHART. Nếu sơ
    // đồ hiện tại chưa từng được "Lưu sơ đồ" (currentId rỗng / chưa khớp
    // dòng nào), backend saveSeatingAccess sẽ báo lỗi "Chưa tìm thấy sơ đồ
    // thật..." và trước đây lỗi này bị nuốt mất, người dùng chỉ thấy im
    // lặng không có gì xảy ra. Ở đây tự lưu layout hiện tại trước để đảm
    // bảo luôn có dòng thật trước khi đổi trạng thái công bố.
    showToast('Đang cập nhật trạng thái công bố...', 'info');
    const { chart, error: saveErr } = await gasSaveChart(currentId, title, seatState, roomConfig);
    if (!chart) {
      showToast(saveErr || 'Không lưu được sơ đồ lên Google Sheets — kiểm tra kết nối rồi thử lại.', 'error');
      return;
    }
    currentId = chart.id;
    saveSeatState(seatState);
    localStorage.setItem(SEAT_CURRENT_KEY, chart.id);
    sheets = await gasListCharts();

    const { access, error } = await gasSaveAccess(currentId, title, status, previewStudents || '');
    if (!access) {
      showToast(error || 'Không lưu được trạng thái công bố — kiểm tra kết nối rồi thử lại.', 'error');
      return;
    }
    publishConfig = access;
  } else {
    writePublish(currentId, { status, previewStudents: previewStudents || '' });
    publishConfig = { status, previewStudents: previewStudents || '' };
  }
  render();
  showToast(
    status === 'published' ? 'Đã công bố sơ đồ cho cả lớp.' :
    status === 'preview'   ? `Đã bật Xem trước — ${(previewStudents||'').split(',').filter(Boolean).length} học sinh được xem.` :
    'Đã chuyển về riêng tư.',
    status === 'private' ? 'warn' : 'success'
  );
}

function on(id, fn) {
  const el = document.getElementById(id);
  if (el) el.addEventListener('click', fn);
}
function openModal(kind) { modal = kind; modalOpening = true; render(); }
function closeModal() {
  const backdrop = document.getElementById('modal-backdrop');
  if (!backdrop) { modal = null; render(); return; }
  // Gỡ is-open trước để backdrop fade mờ dần (transition opacity .3s ease đã
  // khai báo ở CSS), CHỈ THỰC SỰ gỡ khỏi DOM (modal=null + render()) sau khi
  // hiệu ứng chạy xong — không cắt ngang giữa chừng.
  backdrop.classList.remove('is-open');
  setTimeout(() => { modal = null; render(); }, 300);
}
function closeSelect() { if (selectOpen) { selectOpen = false; render(); } }

/* ---------- Handlers ---------- */
function commitSeatState(next) { seatState = next; saveSeatState(next); markDirty(); render(); }

async function applySheet(item) {
  if (!item) return;
  selectOpen = false;
  let layoutSeats = item.layout?.seats || null;
  let layoutRoom  = item.layout?.room || null;

  if (dataSource === 'gas' && !layoutSeats) {
    showToast('Đang mở sơ đồ...', 'info');
    const res = await gasGetChart(item.id);
    if (res.restricted) {
      // Sơ đồ này đang riêng tư và mình không đủ quyền — không có gì để
      // hiển thị, cứ để publishConfig phản ánh đúng trạng thái rồi render()
      // sẽ tự chuyển sang màn hình chặn.
      currentId = item.id;
      publishConfig = { status: res.status || 'private' };
      render();
      showToast('Sơ đồ này đang ở chế độ riêng tư.', 'warn');
      return;
    }
    layoutSeats = res.chart?.layout?.seats || null;
    layoutRoom  = res.chart?.layout?.room || layoutRoom;
  }
  if (!layoutSeats) { showToast('Không đọc được sơ đồ này.', 'error'); return; }

  seatState = { left: normalizeRows(layoutSeats.left), right: normalizeRows(layoutSeats.right) };
  saveSeatState(seatState); // vẫn giữ 1 bản cục bộ để mở nhanh / phòng khi mất mạng
  roomConfig = normalizeRoom(layoutRoom);
  if (dataSource === 'gas') {
    // Vừa fetch (hoặc đã có sẵn) layout thật cho sơ đồ này — ghi vào DB
    // nhiều-sơ-đồ để lần preload/reload sau còn giữ được.
    persistLayoutToDb(item.id, seatState, roomConfig, { title: item.title });
  }
  currentId = item.id;
  localStorage.setItem(SEAT_CURRENT_KEY, item.id);

  if (dataSource === 'gas') {
    publishConfig = await gasGetAccess(currentId, item.title);
  } else {
    publishConfig = readPublish(currentId);
  }
  render();
  showToast(`Đã mở "${item.title || 'sơ đồ'}".`, 'success');
}

async function handleSaveRoomConfig() {
  const title = sheets.find(i => i.id === currentId)?.title || 'Sơ đồ hiện tại';
  if (dataSource === 'gas') {
    showToast('Đang lưu cấu hình phòng...', 'info');
    const { chart, error: saveErr } = await gasSaveChart(currentId, title, seatState, roomConfig);
    if (!chart) { showToast(saveErr || 'Lưu thất bại — kiểm tra kết nối rồi thử lại.', 'error'); return; }
    currentId = chart.id;
    persistLayoutToDb(currentId, seatState, roomConfig, { title });
    sheets = await gasListCharts();
    render();
    showToast('Đã lưu cấu hình phòng.', 'success');
    return;
  }
  const { items, item } = saveSheet(sheets, currentId, title, seatState, roomConfig);
  sheets = items; currentId = item.id;
  render();
  showToast('Đã lưu cấu hình phòng (cục bộ — chưa kết nối Google Sheets).', 'success');
}

/** Lưu sơ đồ. silent=true dùng cho tự động lưu ngầm (không hiện toast, không
 * render() lại toàn bộ để tránh mất focus/giật màn hình giữa lúc đang thao tác);
 * silent=false (mặc định, khi bấm nút "Lưu" thủ công) hiện đầy đủ thông báo. */
async function handleSaveSheet(silent) {
  if (!canEditSeating()) { if (!silent) showToast('Bạn không có quyền sửa sơ đồ.', 'error'); return; }
  clearTimeout(autosaveTimer);
  const title = sheets.find(i => i.id === currentId)?.title || 'Sơ đồ hiện tại';
  isSavingNow = true;
  updateSaveStatus();

  if (dataSource === 'gas') {
    if (!silent) showToast('Đang lưu lên Google Sheets...', 'info');
    const { chart, error: saveErr } = await gasSaveChart(currentId, title, seatState, roomConfig);
    if (!chart) {
      isSavingNow = false; isDirty = true; updateSaveStatus();
      showToast(saveErr || (silent ? 'Tự động lưu thất bại — kiểm tra kết nối.' : 'Lưu thất bại — kiểm tra kết nối rồi thử lại.'), 'error');
      return;
    }
    currentId = chart.id;
    saveSeatState(seatState);
    localStorage.setItem(SEAT_CURRENT_KEY, chart.id);
    persistLayoutToDb(currentId, seatState, roomConfig, { title });
    sheets = await gasListCharts();
    isDirty = false; isSavingNow = false;
    if (silent) updateSaveStatus(); else render();
    if (!silent) showToast('Đã lưu sơ đồ lên Google Sheets.', 'success');
    return;
  }

  const { items, item } = saveSheet(sheets, currentId, title, seatState, roomConfig);
  sheets = items; currentId = item.id;
  isDirty = false; isSavingNow = false;
  if (silent) updateSaveStatus(); else render();
  if (!silent) showToast('Đã lưu sơ đồ (cục bộ — chưa kết nối Google Sheets).', 'success');
}

async function doCreateSheet() {
  if (!canEditSeating()) { showToast('Bạn không có quyền tạo sơ đồ mới.', 'error'); modal = null; render(); return; }
  const inp = document.getElementById('modal-title-input');
  const title = (inp?.value || '').trim();
  if (!title) { inp?.focus(); return; }
  modal = null;

  if (dataSource === 'gas') {
    showToast('Đang tạo sơ đồ mới...', 'info');
    const { chart, error: saveErr } = await gasSaveChart('', title, seatState, roomConfig);
    if (!chart) { showToast(saveErr || 'Tạo sơ đồ thất bại — kiểm tra kết nối rồi thử lại.', 'error'); return; }
    persistLayoutToDb(chart.id, seatState, roomConfig, { title });
    sheets = await gasListCharts();
    await applySheet(chart);
    showToast('Đã tạo sơ đồ mới.', 'success');
    return;
  }

  const { items, item } = saveSheet(sheets, null, title, seatState, roomConfig);
  writePublish(item.id, { status: 'private' });
  sheets = items;
  await applySheet(item);
  showToast('Đã tạo sơ đồ mới.', 'success');
}

/* ---------- Quản lý sơ đồ: đổi tên / sao chép / xoá ---------- */

/** Lấy seats+room đầy đủ của 1 sheet trong danh sách — nếu chưa có sẵn
 * (chế độ gas, sheet đó chưa từng được mở) thì gọi API lấy về. */
async function ensureSheetLayout(item) {
  let seats = item.layout?.seats, room = item.layout?.room;
  if (!seats && dataSource === 'gas') {
    const res = await gasGetChart(item.id);
    seats = res.chart?.layout?.seats || null;
    room  = res.chart?.layout?.room  || null;
  }
  if (!seats) return null;
  return { seats: { left: normalizeRows(seats.left), right: normalizeRows(seats.right) }, room: normalizeRoom(room) };
}

async function doRenameSheet(id, rawTitle) {
  if (!canEditSeating()) return;
  const item = sheets.find(i => i.id === id);
  if (!item) return;
  const title = (rawTitle || '').trim();
  if (!title || title === item.title) { render(); return; } // trống hoặc không đổi gì — khôi phục hiển thị cũ

  if (dataSource === 'gas') {
    const layout = await ensureSheetLayout(item);
    if (!layout) { showToast('Không đọc được sơ đồ để đổi tên.', 'error'); render(); return; }
    showToast('Đang đổi tên...', 'info');
    const { chart, error } = await gasSaveChart(id, title, layout.seats, layout.room);
    if (!chart) { showToast(error || 'Đổi tên thất bại.', 'error'); render(); return; }
    sheets = await gasListCharts();
    render();
    showToast('Đã đổi tên sơ đồ.', 'success');
    return;
  }

  item.title = title;
  item.updatedAt = new Date().toISOString();
  writeDb(sheets);
  render();
  showToast('Đã đổi tên sơ đồ.', 'success');
}

async function doDuplicateSheet(id) {
  if (!canEditSeating()) return;
  const item = sheets.find(i => i.id === id);
  if (!item) return;
  const newTitle = `${item.title || 'Sơ đồ'} (Copy)`;
  const layout = await ensureSheetLayout(item);
  if (!layout) { showToast('Không đọc được sơ đồ để sao chép.', 'error'); return; }

  if (dataSource === 'gas') {
    showToast('Đang sao chép sơ đồ...', 'info');
    const { chart, error } = await gasSaveChart('', newTitle, layout.seats, layout.room);
    if (!chart) { showToast(error || 'Sao chép thất bại.', 'error'); return; }
    persistLayoutToDb(chart.id, layout.seats, layout.room, { title: newTitle });
    sheets = await gasListCharts();
    render();
    showToast('Đã sao chép sơ đồ.', 'success');
    return;
  }

  // saveSheet() tự đánh dấu sheet mới là "active" — không muốn tự chuyển
  // sang sơ đồ vừa sao chép, chỉ thêm vào danh sách rồi giữ nguyên sheet
  // đang mở.
  const { items } = saveSheet(sheets, null, newTitle, layout.seats, layout.room);
  items.forEach(i => { i.active = i.id === currentId; });
  writeDb(items);
  localStorage.setItem(SEAT_CURRENT_KEY, currentId);
  sheets = items;
  render();
  showToast('Đã sao chép sơ đồ.', 'success');
}

async function doDeleteSheet(id) {
  if (!canEditSeating()) return;
  if (sheets.length <= 1) { showToast('Phải còn ít nhất 1 sơ đồ.', 'warn'); return; }
  const item = sheets.find(i => i.id === id);
  if (!item) return;
  if (!window.confirm(`Xoá sơ đồ "${item.title || 'Sơ đồ'}"? Không thể hoàn tác.`)) return;

  if (dataSource === 'gas') {
    showToast('Đang xoá sơ đồ...', 'info');
    // Cần backend (api.gs) hỗ trợ action "deleteSeatingChart" — nếu backend
    // chưa có action này, thao tác sẽ báo lỗi thay vì âm thầm không làm gì.
    const json = await postToGas('deleteSeatingChart', { id, role: userRole || '', actor: { name: userName, role: userRole } });
    const data = gasData(json);
    const ok = json && json.ok !== false && !data.error;
    if (!ok) {
      showToast((data && data.error) || 'Xoá thất bại — có thể backend chưa hỗ trợ xoá sơ đồ.', 'error');
      return;
    }
    sheets = await gasListCharts();
    if (id === currentId) {
      const next = sheets.find(i => i.active) || sheets[0];
      if (next) await applySheet(next);
    }
    render();
    showToast('Đã xoá sơ đồ.', 'success');
    return;
  }

  const items = sheets.filter(i => i.id !== id);
  if (id === currentId) {
    const next = items.find(i => i.active) || items[0];
    if (next) {
      next.active = true;
      currentId = next.id;
      localStorage.setItem(SEAT_CURRENT_KEY, next.id);
      seatState = { left: normalizeRows(next.layout?.seats?.left), right: normalizeRows(next.layout?.seats?.right) };
      saveSeatState(seatState);
      roomConfig = normalizeRoom(next.layout?.room);
      publishConfig = readPublish(currentId);
    }
  }
  writeDb(items);
  sheets = items;
  render();
  showToast('Đã xoá sơ đồ.', 'success');
}

/* ---------- Kéo tự do cửa sổ/cửa bằng chuột ---------- */
function startRoomMove(e, el) {
  if (!canEditSeating() || !editMode) return;
  e.preventDefault();
  const board = document.querySelector('.seat-board');
  if (!board) return;
  const type = el.dataset.roomType;
  const side = el.dataset.roomSide || roomConfig.door.side;
  const index = el.dataset.roomIndex != null ? +el.dataset.roomIndex : null;
  const startTop = type === 'window' ? roomConfig.windows[side][index].top : roomConfig.door.top;
  roomDrag = { type, origSide: side, index, el, board, lastSide: side, lastTopPct: startTop };
  document.body.classList.add('seat-room-dragging');
  el.classList.add('is-dragging-room');
  document.addEventListener('mousemove', onRoomMoveMove);
  document.addEventListener('mouseup', onRoomMoveEnd);
}
function onRoomMoveMove(e) {
  if (!roomDrag) return;
  const boardRect = roomDrag.board.getBoundingClientRect();
  const relY = Math.min(Math.max(e.clientY - boardRect.top, 0), boardRect.height);
  const topPct = Math.min(96, Math.max(2, (relY / boardRect.height) * 100));
  const midX = boardRect.left + boardRect.width / 2;
  const newSide = e.clientX < midX ? 'left' : 'right';
  if (newSide !== roomDrag.lastSide) {
    roomDrag.el.classList.remove(roomDrag.lastSide);
    roomDrag.el.classList.add(newSide);
    roomDrag.lastSide = newSide;
  }
  roomDrag.el.style.top = `${topPct}%`;
  roomDrag.lastTopPct = topPct;
}
function onRoomMoveEnd() {
  if (!roomDrag) return;
  document.removeEventListener('mousemove', onRoomMoveMove);
  document.removeEventListener('mouseup', onRoomMoveEnd);
  document.body.classList.remove('seat-room-dragging');
  const { type, origSide, index, lastSide, lastTopPct } = roomDrag;
  const next = cloneRoom(roomConfig);
  if (type === 'window') {
    const item = next.windows[origSide][index];
    next.windows[origSide].splice(index, 1);
    next.windows[lastSide].push({ top: lastTopPct, height: item.height });
  } else {
    next.door.side = lastSide;
    next.door.top = lastTopPct;
  }
  roomConfig = normalizeRoom(next);
  roomDrag = null;
  markDirty();
  render();
  showToast('Đã đổi vị trí — đang tự lưu.', 'info');
}

function startRoomResize(e, handle) {
  if (!canEditSeating() || !editMode) return;
  e.preventDefault();
  const el = handle.closest('[data-room-type]');
  const board = document.querySelector('.seat-board');
  if (!el || !board) return;
  const boardRect = board.getBoundingClientRect();
  const scale = boardRect.height / (board.clientHeight || 1);
  roomResize = {
    type: el.dataset.roomType,
    side: el.dataset.roomSide || roomConfig.door.side,
    index: el.dataset.roomIndex != null ? +el.dataset.roomIndex : null,
    el, startY: e.clientY, startHeight: el.offsetHeight / scale, scale,
    lastHeight: null,
  };
  document.body.classList.add('seat-room-dragging');
  document.addEventListener('mousemove', onRoomResizeMove);
  document.addEventListener('mouseup', onRoomResizeEnd);
}
function onRoomResizeMove(e) {
  if (!roomResize) return;
  const deltaPx = (e.clientY - roomResize.startY) / roomResize.scale;
  const newHeight = Math.min(260, Math.max(30, Math.round(roomResize.startHeight + deltaPx)));
  roomResize.el.style.height = `${newHeight}px`;
  roomResize.lastHeight = newHeight;
}
function onRoomResizeEnd() {
  if (!roomResize) return;
  document.removeEventListener('mousemove', onRoomResizeMove);
  document.removeEventListener('mouseup', onRoomResizeEnd);
  document.body.classList.remove('seat-room-dragging');
  const { type, side, index, lastHeight } = roomResize;
  if (lastHeight) {
    const next = cloneRoom(roomConfig);
    if (type === 'window') next.windows[side][index].height = lastHeight;
    else next.door.height = lastHeight;
    roomConfig = normalizeRoom(next);
  }
  roomResize = null;
  markDirty();
  render();
  showToast('Đã đổi kích thước — đang tự lưu.', 'info');
}

function handleFrontDrop(targetIdx) {
  if (!canEditSeating() || !editMode) return;
  if (dragFrontIndex === null || dragFrontIndex === targetIdx) { dragFrontIndex = null; return; }
  const next = cloneRoom(roomConfig);
  const tmp = next.front[targetIdx];
  next.front[targetIdx] = next.front[dragFrontIndex];
  next.front[dragFrontIndex] = tmp;
  // Cửa vật lý ở tường trái/phải tự đồng bộ theo vị trí mới của ô "CỬA RA VÀO"
  const doorIdx = next.front.findIndex(f => f.key === 'door');
  if (doorIdx === 0) next.door.side = 'left';
  else if (doorIdx === 2) next.door.side = 'right';
  roomConfig = normalizeRoom(next);
  dragFrontIndex = null;
  markDirty();
  render();
  showToast('Đã đổi vị trí — đang tự lưu.', 'info');
}

function handleReset() {
  if (!canEditSeating()) return;
  if (!editMode) { showToast('Bấm "Bật sửa" trước khi khôi phục sơ đồ.', 'warn'); return; }
  if (!window.confirm('Xoá toàn bộ chỗ ngồi, trả về lưới trống?')) return;
  lockedStudents.clear();
  saveLockedStudents(lockedStudents);
  commitSeatState(cloneState(SEAT_DEFAULT));
}

function handleRandom() {
  if (!canEditSeating()) return;
  if (!editMode) { showToast('Bấm "Bật sửa" trước khi random chỗ ngồi.', 'warn'); return; }
  const positions = [], names = [];
  let lockedCount = 0;
  for (const side of ['left', 'right']) {
    seatState[side].forEach((row, rowIdx) =>
      row.forEach((name, seatIdx) => {
        if (!name) return;
        // Học sinh đã khoá chỗ (đã "ok" chỗ ngồi) — giữ nguyên, không đưa
        // vào danh sách xáo trộn, chỉ random những người còn lại.
        if (lockedStudents.has(name)) { lockedCount++; return; }
        positions.push({ side, row: rowIdx, seat: seatIdx });
        names.push(name);
      })
    );
  }
  if (names.length < 2) {
    showToast(lockedCount > 0 ? 'Còn quá ít học sinh chưa khoá để random.' : 'Không đủ học sinh để random.', 'warn');
    return;
  }
  const shuffled = names.slice();
  for (let i = shuffled.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  let next = cloneState(seatState);
  positions.forEach((pos, i) => { next = withSeatSet(next, pos, shuffled[i]); });
  commitSeatState(next);
  showToast(
    lockedCount > 0
      ? `Đã random ${names.length} học sinh (giữ nguyên ${lockedCount} chỗ đã khoá). Đang tự lưu.`
      : 'Đã random chỗ ngồi. Đang tự lưu.',
    'success',
  );
}

/* Đổi bên toàn bộ chỗ ngồi — lấy "lối đi" làm trục đối xứng.
 * Với mỗi hàng, ghế ở khoảng cách d tính từ lối đi bên trái (cột 3-d, vì
 * cột 3 là cột sát lối đi nhất) được hoán đổi với ghế cùng khoảng cách d
 * bên phải (cột d, vì cột 0 bên phải sát lối đi nhất) — nên sau khi đổi,
 * khoảng cách từ chỗ mới đến lối đi luôn bằng khoảng cách từ chỗ cũ đến
 * lối đi. Cặp nào có 1 trong 2 chỗ đã khoá thì giữ nguyên cả cặp, không đổi. */
function handleSwapSide() {
  if (!canEditSeating()) return;
  if (!editMode) { showToast('Bấm "Bật sửa" trước khi đổi bên.', 'warn'); return; }
  if (!window.confirm('Đổi bên toàn bộ chỗ ngồi (trái ↔ phải)? Khoảng cách từ mỗi chỗ đến lối đi sẽ được giữ nguyên. Các chỗ đã khoá sẽ không bị đổi.')) return;

  let next = cloneState(seatState);
  let swappedPairs = 0, skippedLocked = 0;

  for (let row = 0; row < seatState.left.length; row++) {
    for (let d = 0; d < 4; d++) {
      const leftPos  = { side: 'left',  row, seat: 3 - d };
      const rightPos = { side: 'right', row, seat: d };
      const leftName  = seatAt(seatState, leftPos);
      const rightName = seatAt(seatState, rightPos);
      if ((leftName && lockedStudents.has(leftName)) || (rightName && lockedStudents.has(rightName))) {
        if (leftName || rightName) skippedLocked++;
        continue; // có chỗ đã khoá trong cặp — giữ nguyên, không đổi
      }
      if (leftName === rightName) continue; // cả hai cùng trống (hoặc trùng) — không cần đổi
      next = withSeatSet(next, leftPos, rightName);
      next = withSeatSet(next, rightPos, leftName);
      swappedPairs++;
    }
  }

  if (swappedPairs === 0) {
    showToast(
      skippedLocked > 0
        ? 'Các cặp chỗ đối xứng còn lại đều có chỗ đã khoá — không có gì để đổi bên.'
        : 'Không có chỗ ngồi nào cần đổi bên.',
      'warn',
    );
    return;
  }

  commitSeatState(next);
  showToast(
    skippedLocked > 0
      ? `Đã đổi bên ${swappedPairs} cặp chỗ (giữ nguyên ${skippedLocked} cặp có chỗ đã khoá). Đang tự lưu.`
      : `Đã đổi bên ${swappedPairs} cặp chỗ. Đang tự lưu.`,
    'success',
  );
}

function handleToggleLock(name) {
  if (!canEditSeating() || !editMode || !name) return;
  if (lockedStudents.has(name)) lockedStudents.delete(name);
  else lockedStudents.add(name);
  saveLockedStudents(lockedStudents);
  render();
}

/* Kéo học sinh từ 1 ghế ra khu "Danh sách học sinh" → trả về chưa xếp chỗ. */
function handleUnassignDrop() {
  if (!canEditSeating() || !dragPayload) { dragPayload = null; return; }
  if (dragPayload.type !== 'seat') { dragPayload = null; return; } // đã ở sidebar rồi thì thôi
  if (lockedStudents.has(dragPayload.name)) {
    showToast(`"${dragPayload.name}" đang khoá chỗ — bỏ khoá trước khi bỏ ra khỏi ghế.`, 'warn');
    dragPayload = null;
    return;
  }
  commitSeatState(withSeatSet(seatState, dragPayload.pos, ''));
  dragPayload = null;
}

function handleDrop(target) {
  if (!canEditSeating() || !dragPayload || !dragPayload.name) return;
  // Chặn đổi chỗ nếu học sinh đang kéo, hoặc học sinh đang ngồi ở ô đích,
  // đã được khoá — phải bỏ khoá trước mới di chuyển được.
  const targetName = seatAt(seatState, target);
  if (targetName && lockedStudents.has(targetName)) {
    showToast(`"${targetName}" đang khoá chỗ — bỏ khoá trước khi đổi.`, 'warn');
    dragPayload = null;
    return;
  }
  if (dragPayload.type === 'seat' && lockedStudents.has(dragPayload.name)) {
    showToast(`"${dragPayload.name}" đang khoá chỗ — bỏ khoá trước khi đổi.`, 'warn');
    dragPayload = null;
    return;
  }
  commitSeatState(withSeatMove(seatState, dragPayload, target));
  dragPayload = null;
}

function updateSeatCountdownText() {
  const el = document.getElementById('seat-blocked-countdown-num');
  if (el) el.textContent = String(seatAccessCountdown);
}

function startAccessPolling() {
  // GVCN/lớp trưởng luôn xem/sửa được — không cần tự mở/tự khoá theo trạng
  // thái công bố. Không có gasUrl thì cũng không có gì để hỏi lại.
  if (!gasUrl || canEditSeating() || seatAccessPollTimer) return;
  seatAccessPollTimer = setInterval(() => {
    seatAccessCountdown -= 1;
    if (seatAccessCountdown > 0) { updateSeatCountdownText(); return; }
    seatAccessCountdown = SEAT_ACCESS_POLL_SECONDS;
    checkAccessNow();
  }, 1000);
}

// Hỏi lại trạng thái công bố mỗi 10 giây (đồng hồ đếm ngược ở trên).
// Dùng action nhẹ "watchSeatingChart" (chỉ trả id + version + accessStatus)
// thay vì gọi "getSeatingAccess" đầy đủ — giảm tải đáng kể khi nhiều học
// sinh cùng mở sơ đồ và poll đồng thời.
// Logic xử lý:
// - Không thay đổi gì (version + accessStatus giữ nguyên) → chỉ tick đồng hồ.
// - accessStatus đổi → gọi thêm getSeatingChartWithAccess để lấy layout thật
//   + access đầy đủ (1 roundtrip), rồi áp vào UI.
let _lastWatchVersion    = 0;
let _lastWatchAccStatus  = '';

async function gasWatchChart(id) {
  const json = await fetchFromGas({ action: 'watchSeatingChart', id: id || '' });
  const data = gasData(json);
  if (!data.id) return null;
  return {
    id:           data.id,
    version:      Number(data.version  || 0),
    updatedAt:    data.updatedAt || '',
    // Worker trả accessStatus theo giá trị API ('public'/'restricted'/'private');
    // dịch sang UI-label ngay tại đây để các so sánh bên dưới nhất quán.
    accessStatus: seatStatusFromApi(data.accessStatus || 'private'),
  };
}

async function checkAccessNow() {
  if (!gasUrl || canEditSeating()) return;

  const wasBlocked = !canViewSeating(
    publishConfig.status || 'private',
    publishConfig.previewStudents || publishConfig.preview_students || '',
  );

  // ── Bước 1: poll nhẹ — chỉ metadata ──────────────────────────────────────
  const watch = await gasWatchChart(currentId);
  if (!watch) { updateSeatCountdownText(); return; } // lỗi mạng tạm thời

  const versionUnchanged   = watch.version    === _lastWatchVersion;
  const accStatusUnchanged = watch.accessStatus === _lastWatchAccStatus;

  if (versionUnchanged && accStatusUnchanged && _lastWatchVersion !== 0) {
    // Không có gì thay đổi — chỉ tick đếm ngược, không fetch thêm.
    updateSeatCountdownText();
    return;
  }

  // ── Bước 2: có thay đổi → lấy đầy đủ (chart + access) ───────────────────
  _lastWatchVersion   = watch.version;
  _lastWatchAccStatus = watch.accessStatus;

  const title    = sheets.find(i => i.id === currentId)?.title || '';
  const combined = await gasGetChartWithAccess(currentId, title);

  let access;
  if (combined !== null) {
    // Backend hỗ trợ action gộp — 1 roundtrip
    if (combined.chart?.layout?.seats && !combined.restricted) {
      seatState = {
        left:  normalizeRows(combined.chart.layout.seats.left),
        right: normalizeRows(combined.chart.layout.seats.right),
      };
      saveSeatState(seatState);
      if (dataSource === 'gas') {
        roomConfig = normalizeRoom(combined.chart.layout.room || roomConfig);
        persistLayoutToDb(currentId, seatState, roomConfig, { title });
      }
    }
    access = combined.access;
  } else {
    // Fallback: 2 request song song (backend cũ không có action gộp)
    const [res, acc] = await Promise.all([
      gasGetChart(currentId),
      gasGetAccess(currentId, title),
    ]);
    if (res.chart?.layout?.seats && !res.restricted) {
      seatState = {
        left:  normalizeRows(res.chart.layout.seats.left),
        right: normalizeRows(res.chart.layout.seats.right),
      };
      saveSeatState(seatState);
      if (dataSource === 'gas') {
        roomConfig = normalizeRoom(res.chart.layout.room || roomConfig);
        persistLayoutToDb(currentId, seatState, roomConfig, { title });
      }
    }
    access = acc;
  }

  if (!access) { updateSeatCountdownText(); return; }
  publishConfig = access;

  const isBlockedNow = !canViewSeating(
    publishConfig.status || 'private',
    publishConfig.previewStudents || publishConfig.preview_students || '',
  );
  const newStatus = publishConfig.status || 'private';

  if (wasBlocked && !isBlockedNow) {
    showToast(
      newStatus === 'preview'
        ? 'Bạn vừa được thêm vào danh sách xem trước.'
        : 'Sơ đồ vừa được công bố.',
      'success',
    );
    render();
  } else if (!wasBlocked && isBlockedNow) {
    showToast('Sơ đồ đã được chuyển về chế độ riêng tư.', 'warn');
    render();
  } else if (isBlockedNow) {
    updateSeatCountdownText();
  } else {
    // Sơ đồ cập nhật nội dung nhưng trạng thái công bố không đổi — re-render
    // để hiện layout mới mà không cần người dùng tải lại trang.
    render();
  }
}

/* ---------- Boot ---------- */
async function boot() {
  // ── Bước 1: Hiện ngay cache từ lần trước (stale-while-revalidate) ──────────
  // loadSeatState() đã đọc DB local ở trên — render() hiện luôn không trắng màn
  // hình. Người dùng thấy sơ đồ gần như tức thì; GAS fetch chạy ngầm phía sau.
  render();

  if (!gasUrl) { dataSource = 'local'; return; }

  try {
    // ── Bước 2: Fetch danh sách sơ đồ (nhẹ, chỉ metadata) ──────────────────
    const charts = await gasListCharts();
    dataSource = 'gas';

    if (charts.length) {
      sheets = charts;
      const active = charts.find(c => c.active) || charts[0];
      currentId = active.id;

      // ── Bước 3: Gộp getChart + getAccess → 1 request song song ─────────────
      // Thử action mới (getSeatingChartWithAccess) trước; nếu backend chưa hỗ
      // trợ thì fallback về 2 request song song để vẫn nhanh hơn tuần tự.
      let res, access;
      const combined = await gasGetChartWithAccess(currentId, active.title);
      if (combined !== null) {
        // Backend hỗ trợ action gộp — 1 roundtrip duy nhất
        res    = { chart: combined.chart, restricted: combined.restricted, status: combined.status };
        access = combined.access;
      } else {
        // Fallback: 2 request chạy SONG SONG (Promise.all) thay vì tuần tự
        [res, access] = await Promise.all([
          gasGetChart(currentId),
          gasGetAccess(currentId, active.title),
        ]);
      }

      // res.restricted === true nghĩa là sơ đồ đang riêng tư và mình không
      // đủ quyền — không có seats thật để nạp, cứ để publishConfig (đọc
      // bên dưới, luôn cho phép xem status) quyết định render() có chặn hay
      // không, không hiện tạm dữ liệu mặc định cục bộ đánh lừa người xem.
      if (res.chart?.layout?.seats) {
        seatState = { left: normalizeRows(res.chart.layout.seats.left), right: normalizeRows(res.chart.layout.seats.right) };
        saveSeatState(seatState);
      }
      roomConfig = normalizeRoom(res.chart?.layout?.room);
      if (res.chart?.layout?.seats) {
        // Ghi lại vào DB nhiều-sơ-đồ để lần preload/reload sau còn giữ được
        // (xem comment ở persistLayoutToDb).
        persistLayoutToDb(currentId, seatState, roomConfig, { title: active.title, active: true });
      }
      publishConfig = access;
      // Ghi baseline cho watchSeatingChart: poll đầu tiên sau boot() sẽ bỏ
      // qua fetch đầy đủ nếu version + accessStatus chưa thay đổi.
      _lastWatchAccStatus = publishConfig.status || 'private';
    } else {
      // Sheet SEATING CHART chưa có sơ đồ nào — vẫn hiện dữ liệu mặc định
      // cục bộ; bấm "Lưu sơ đồ" sẽ tạo dòng đầu tiên thật trên Sheet.
      sheets = [];
      currentId = '';
      roomConfig = normalizeRoom(null);
      publishConfig = { status: 'private' };
    }
    render();
  } catch (e) {
    dataSource = 'local';
    showToast('Không kết nối được Google Sheets — đang dùng dữ liệu cục bộ.', 'warn');
  }

  startAccessPolling();
}

/* ---------- Fit-to-screen: scale .seat-board để vừa .seat-board-wrap ----------
   Chạy sau mỗi render() và khi cửa sổ thay đổi kích thước. CSS overflow:hidden
   loại scrollbar; transform:scale() thu nhỏ nội dung thay vì cắt bỏ.          */
function fitBoard() {
  const wrap  = document.querySelector('.seat-board-wrap');
  const board = document.querySelector('.seat-board');
  if (!wrap || !board) return;

  // Mobile (≤900px): board giữ kích thước tự nhiên, wrap cuộn ngang+dọc.
  // Không scale — xoá transform cũ nếu có rồi thoát.
  if (window.matchMedia('(max-width:900px)').matches) {
    board.style.transform = '';
    board.style.transformOrigin = '';
    board.style.width  = '';
    board.style.height = '';
    return;
  }

  // Desktop: scale board để vừa wrap (fit-to-screen), không cuộn.
  // Reset về tự nhiên trước khi đo để không bị ảnh hưởng bởi scale cũ.
  board.style.transform = '';
  board.style.transformOrigin = '';
  board.style.width  = '';
  board.style.height = '';

  const wW = wrap.clientWidth;
  const wH = wrap.clientHeight;
  const bW = board.scrollWidth;
  const bH = board.scrollHeight;

  // Guard: iframe/WebView chưa layout xong → 0, tránh NaN/Infinity.
  if (!wW || !bW || !wH || !bH) return;

  const scale = Math.min(wW / bW, wH / bH, 1); // chỉ thu nhỏ, không phóng to

  if (scale < 1) {
    board.style.transformOrigin = 'top left';
    board.style.transform = `scale(${scale})`;
    // Set kích thước box = nội dung tự nhiên để overflow:hidden không
    // cắt trước khi scale áp dụng.
    board.style.width  = `${bW}px`;
    board.style.height = `${bH}px`;
  }
}

let _fitBoardTimer = null;
function scheduleFitBoard() {
  clearTimeout(_fitBoardTimer);
  _fitBoardTimer = setTimeout(fitBoard, 40);
}

function initSeating(opts = {}) {
  gasUrl    = opts.gasUrl    || null;
  userRole  = opts.userRole  || null;
  userGroup = opts.userGroup != null ? String(opts.userGroup) : null;
  // Reset watch-state khi khởi tạo mới để poll đầu tiên luôn fetch đầy đủ.
  _lastWatchVersion   = 0;
  _lastWatchAccStatus = '';
  window.addEventListener('resize', scheduleFitBoard);
  void boot();
}

/* Auto-init khi dùng độc lập (không qua seating-window.html gọi initSeating) */
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('seating-root') && !window.__seating_manual_init) initSeating();
  });
} else if (document.getElementById('seating-root') && !window.__seating_manual_init) {
  initSeating();
}